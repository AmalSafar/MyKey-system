package com.example.lockdevice;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Locale;

import Model.DatabaseHandler;

public class primeOwner extends AppCompatActivity {


    private String product_NO;
    private String userid;
    private String username;
    private String phonenumber;
    private String password;
    DatabaseHandler DB  = new DatabaseHandler(this);
    private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.prime_option);

        Button scan_key = (Button)findViewById(R.id.butoon_scan_key);
        scan_key.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                setPassword(MainActivity.OwnedLock.get(0).getPassword());

                IntentIntegrator intentIntegrator = new IntentIntegrator(primeOwner.this);

                intentIntegrator.setPrompt("for flash use volume up key");

                intentIntegrator.setBeepEnabled(true);

                intentIntegrator.setOrientationLocked(true);

                intentIntegrator.setCaptureActivity(Capture.class);

                intentIntegrator.initiateScan();

            }
        });
        //open scanner page

        //after scanner display activation code

        //key have been added succefully
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        IntentResult intentResult = IntentIntegrator.parseActivityResult(requestCode,resultCode,data);

        if(intentResult.getContents() != null){

            AlertDialog.Builder builder = new AlertDialog.Builder(primeOwner.this);



            String QRcontent = intentResult.getContents();
            Toast.makeText(getApplicationContext(),""+QRcontent, Toast.LENGTH_SHORT).show();

            try {
                boolean validAccess = checkExpireTime(QRcontent);//content will be OTP
                if(validAccess){
                    builder.setTitle("Successed");
                    builder.setMessage("");
                }else{
                    builder.setTitle("Denied");
                    builder.setMessage("Smart Key expired, Please try again");
                }

            } catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
            }


            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                }
            });

            builder.show();

        }else{

            Toast.makeText(getApplicationContext(), "OOPS .. You didn't scan anything", Toast.LENGTH_SHORT).show();

        }

    }

    public primeOwner() {
    }

    public primeOwner( String product_NO,String userid , String password) {
        this.product_NO = product_NO;
        this.userid = userid;
        this.password = password;

    }

    public primeOwner( String product_NO,String userid, String username, String phonenumber) {
        this.product_NO = product_NO;
        this.userid = userid;
        this.username = username;
        this.phonenumber = phonenumber;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }



// check the validity of scanned key (QR)
    public boolean checkExpireTime(String OTP) throws NoSuchAlgorithmException {
        //HH:MM - 1
        //generate current time
        //calculate OTP of 1 minutes before and 1 minute after current time OTP
        //compared all three with scanned one
        //calculate OTP for
        ArrayList<String> OTPs = new ArrayList<String>();
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        //generate current time and store its OTP in array
        String timeFormat = sdf.format(timestamp);
        String currtime = timeFormat+""+getPassword();//;
        String encrypted = toHexString(getSHA(currtime));
        int firstOTP = OTP(encrypted);
        OTPs.add(firstOTP+"");
        //subtract 1 minute
        //take OTP and store in array
        int min = timestamp.getMinutes();
        timestamp.setMinutes(min-1);
        int minu2 =min-1;
        String timeFormat1 = sdf.format(timestamp);
        String currtime1 = timeFormat1+""+getPassword();
        String encrypted1 = toHexString(getSHA(currtime1));
        System.out.println("2- " +currtime1 );
        int secondOTP = OTP(encrypted1);
        OTPs.add(secondOTP+"");






        //add 1 minute
        //take OTP and store in array
        timestamp.setMinutes(min+1);
        String timeFormat2 = sdf.format(timestamp);
        String currtime2 = timeFormat2+""+getPassword();
        String encrypted2 = toHexString(getSHA(currtime2));
        int thirdOTP = OTP(encrypted2);
        OTPs.add(thirdOTP+"");
        boolean access = false;
        for(int i = 0 ; i < OTPs.size() ; i++){
            if(OTP.equalsIgnoreCase(OTPs.get(i))){
                access = true;
            }
        }
        return access;
    }

    public static int OTP(String secretPass){

        String nu = secretPass.substring(0,18);
        long d = Long.parseLong(nu);
        double dd = d %  Math.pow(10, 6);
        int OTP = (int) dd;
        String code = OTP+"";

        return OTP;
    }



    // check if product number exist

    public boolean checkProductNo(){

      String existProduct = DB.getProduct();

      if(existProduct.equalsIgnoreCase(getProduct_NO())){

          return true;
      }else{
          Toast.makeText(getApplicationContext(),"Sorry invalid Product Number, try again", Toast.LENGTH_SHORT).show();
          return false;
      }

    }

    public static byte[] getSHA(String secretKey) throws NoSuchAlgorithmException, NoSuchAlgorithmException {
        // Static getInstance method is called with hashing SHA
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        // digest() method called
        // to calculate message digest of an input
        // and return array of byte
        return md.digest(secretKey.getBytes());
    }

    public static String toHexString(byte[] hash)
    {
        // Convert byte array into signum representation
        BigInteger number = new BigInteger(1, hash);
        // Convert message digest into hex value
        StringBuilder hexString = new StringBuilder(number.toString(10));

        // Pad with leading zeros
        while (hexString.length() < 32)
        {
            hexString.insert(0, '0');
        }
        return hexString.toString();
    }


    public String getProduct_NO() {
        return product_NO;
    }

    public void setProduct_NO(String product_NO) {
        this.product_NO = product_NO;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
    }
}
