package com.example.lockdevice;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import com.journeyapps.barcodescanner.BarcodeEncoder;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;

public class secondaryOwner extends AppCompatActivity {

    private String userName;
    private String accessType;
    private String lockName;
    private long phone;
    private String email;
    private int sequentialID = 0;
    private ArrayList<secondaryOwner> secondaryOwners = new ArrayList<>();

    //return object and added to the array

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        IntentIntegrator intentIntegrator = new IntentIntegrator(secondaryOwner.this);

        intentIntegrator.setPrompt("for flash use volume up key");

        intentIntegrator.setBeepEnabled(true);

        intentIntegrator.setOrientationLocked(true);

        intentIntegrator.setCaptureActivity(Capture.class);

        intentIntegrator.initiateScan();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        IntentResult intentResult = IntentIntegrator.parseActivityResult(requestCode,resultCode,data);

        if(intentResult.getContents() != null){

            AlertDialog.Builder builder = new AlertDialog.Builder(secondaryOwner.this);

            builder.setTitle("");

            String QRcontent = intentResult.getContents();

            //check if the user id and product number is correct for primary owner of the lock
            boolean valid = checkPrimeOWner(QRcontent);

            //if found then secondary owner will be added
            if(valid){
                try {
                    String code = generateQR(QRcontent);
                    addSecondary(QRcontent);
                    builder.setMessage("Enter this code " + code +" on the App to be synchronized successfully");
                } catch (NoSuchAlgorithmException e) {
                    e.printStackTrace();
                }
            }else{
                builder.setMessage("Something went wrong!");
            }

            // builder.setMessage(intentResult.getContents());
            //set activation code
            //try {
            //     builder.setMessage(generateActivation(QRcontent));
            //  } catch (NoSuchAlgorithmException e) {
            //      e.printStackTrace();
            //  }

            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                }
            });

            builder.show();

        }else{

            Toast.makeText(getApplicationContext(), "OOPS .. You didn't scan anything", Toast.LENGTH_SHORT).show();

        }

    }
    public secondaryOwner(){

    }

    public secondaryOwner(String userName , String accessType,String lockName, long phone ,String email){
         this.sequentialID += 1;
         this.userName =userName;
         this.accessType=accessType;
         this.lockName=lockName;
         this.phone=phone;
         this.email=email;
    }

    public boolean checkPrimeOWner(String QRContent){

        String line[] = QRContent.split(" ");
        String productNum = line[0];
        String id = line[1];
        boolean exist=false;
            for(int i = 0 ; i <  MainActivity.OwnedLock.size()-1 ; i++){
                if( MainActivity.OwnedLock.get(i).getProduct_NO().equalsIgnoreCase(productNum)){
                    if( MainActivity.OwnedLock.get(i).getUserid().equalsIgnoreCase(id)){
                        exist=true;
                    }
                }
            }
            return exist;
    }

    public String generateQR(String content) throws NoSuchAlgorithmException {

        String information = content;
        Toast.makeText(getApplicationContext(),information, Toast.LENGTH_SHORT).show();
        String encryptedInfo = toHexString(getSHA(information));
        String code1 = encryptedInfo.substring(0,19);
        long OTP1 = Long.parseLong(code1);
        double dd = OTP1 %  Math.pow(10, 6);
        int OTP = (int) dd;
        String code = OTP+"";

        return code;
    }

    public static byte[] getSHA(String secretKey) throws NoSuchAlgorithmException, NoSuchAlgorithmException {
        // Static getInstance method is called with hashing SHA
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        // digest() method called
        // to calculate message digest of an input
        // and return array of byte
        return md.digest(secretKey.getBytes());
    }
    public static String toHexString(byte[] hash)
    {
        // Convert byte array into signum representation
        BigInteger number = new BigInteger(1, hash);
        // Convert message digest into hex value
        StringBuilder hexString = new StringBuilder(number.toString(10));

        // Pad with leading zeros
        while (hexString.length() < 32)
        {
            hexString.insert(0, '0');
        }
        return hexString.toString();
    }


    public void addSecondary(String QRContent){

        String line[] = QRContent.split(" ");
        String userName = line[2];
        String phone = line[3];
        String email = line[4];
        String lockName = line[5];
        String accessType = line[6];

        long number = Long.parseLong(phone);
        secondaryOwner secondOwner = new secondaryOwner( userName ,  accessType, lockName, number , email);
        this.secondaryOwners.add(secondOwner);

    }

    public int getSequentialID() {
        return sequentialID;
    }

    public void setSequentialID(int sequentialID) {
        this.sequentialID = sequentialID;
    }
}
