package com.example.lockdevice;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Date;
import java.util.ArrayList;

public class temporaryUser extends AppCompatActivity {

    private String userName;
    private String accessType;
    private String KeyName;
    private String DateFrom;
    private String DateTo;
    private String TimeFrom;
    private String TimeTo;
    private int sequentialID = 0;
    private ArrayList<temporaryUser> temporaryUsers = new ArrayList<>();

    //return object and added to the array
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        IntentIntegrator intentIntegrator = new IntentIntegrator(temporaryUser.this);

        intentIntegrator.setPrompt("for flash use volume up key");

        intentIntegrator.setBeepEnabled(true);

        intentIntegrator.setOrientationLocked(true);

        intentIntegrator.setCaptureActivity(Capture.class);

        intentIntegrator.initiateScan();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        IntentResult intentResult = IntentIntegrator.parseActivityResult(requestCode,resultCode,data);

        if(intentResult.getContents() != null){

            AlertDialog.Builder builder = new AlertDialog.Builder(temporaryUser.this);

            builder.setTitle("");


            String QRcontent = intentResult.getContents();

            //check if the user id and product number is correct for primary owner of the lock

            String line[] = QRcontent.split(" ");
            String productNum = line[0];
            String id = line[1];
            boolean valid = checkIfOwnerExist(id,productNum);
            Toast.makeText(getApplicationContext(),"productNum "+productNum , Toast.LENGTH_SHORT).show();
            Toast.makeText(getApplicationContext(),"id "+id , Toast.LENGTH_SHORT).show();

            // read user type if temp search on DB

            if(valid){
                try {
                    String code = generateQR(QRcontent);
                    builder.setMessage("Enter this code " + code +" on the App to synchronize Temporary user successfully");
                } catch (NoSuchAlgorithmException e) {
                    e.printStackTrace();
                }
            }else{
                builder.setMessage("Something went wrong!");
            }

            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                }
            });

            builder.show();

        }else{

            Toast.makeText(getApplicationContext(), "OOPS .. You didn't scan anything", Toast.LENGTH_SHORT).show();

        }

    }

    public temporaryUser() {
    }

    public temporaryUser(String keyName , String userName, String dateFrom, String dateTo, String timeFrom, String timeTo, String accessType) {

        this.userName = userName;
        this.accessType = accessType;
        this.KeyName = keyName;
        this.DateFrom = dateFrom;
        this.DateTo = dateTo;
        this.TimeFrom = timeFrom;
        this.TimeTo = timeTo;
        this.sequentialID +=1;
    }



    public String generateQR(String content) throws NoSuchAlgorithmException {

        String information = content;
        Toast.makeText(getApplicationContext(),information, Toast.LENGTH_SHORT).show();
        String encryptedInfo = MainActivity.toHexString(getSHA(information));
        String code1 = encryptedInfo.substring(0,19);
        long OTP1 = Long.parseLong(code1);
        double dd = OTP1 %  Math.pow(10, 6);
        int OTP = (int) dd;
        String code = OTP+"";

        return code;
    }

    public boolean checkIfOwnerExist(String id, String number){
        boolean exist=false;
        for(int i = 0 ; i < MainActivity.OwnedLock.size()-1 ; i++){
            if(MainActivity.OwnedLock.get(i).getProduct_NO().equalsIgnoreCase(number)){
                Toast.makeText(getApplicationContext(), MainActivity.OwnedLock.get(i).getProduct_NO(), Toast.LENGTH_SHORT).show();
                if(MainActivity.OwnedLock.get(i).getUserid().equalsIgnoreCase(id)){
                    Toast.makeText(getApplicationContext(), MainActivity.OwnedLock.get(i).getUserid(), Toast.LENGTH_SHORT).show();
                    exist=true;
                }
            }
        }
        return exist;
    }
    public void addTempUser(String QRContent){

        String line[] = QRContent.split(" ");
        String KeyName=line[2];
        String userName = line[3];
        String dateFrom=line[4];
        Date DateFrom = Date.valueOf(dateFrom);
        String dateTo=line[5];
        Date DateTo = Date.valueOf(dateTo);
        String TimeFrom=line[6];
        long timeFrom = Date.valueOf(TimeFrom).getTime();
        String timeTo=line[7];
        long TimeTo = Date.valueOf(timeTo).getTime();
        String accessType = line[8];

        temporaryUser tempUser = new temporaryUser( KeyName ,  userName, dateFrom, dateTo , TimeFrom,timeTo,accessType);
        this.temporaryUsers.add(tempUser);

    }

    ///////////////////////////////////////////////

    public boolean checkPrimeOWner(String QRContent){

        String line[] = QRContent.split(" ");
        String productNum = line[0];
        String id = line[1];
        boolean exist=false;
        for(int i = 0 ; i <  MainActivity.OwnedLock.size()-1 ; i++){
            if( MainActivity.OwnedLock.get(i).getProduct_NO().equalsIgnoreCase(productNum)){
                if( MainActivity.OwnedLock.get(i).getUserid().equalsIgnoreCase(id)){
                    exist=true;
                }
            }
        }
        return exist;
    }



    public static byte[] getSHA(String secretKey) throws NoSuchAlgorithmException, NoSuchAlgorithmException {
        // Static getInstance method is called with hashing SHA
        MessageDigest md = MessageDigest.getInstance("SHA-256");

        return md.digest(secretKey.getBytes());
    }
    public static String toHexString(byte[] hash)
    {
        // Convert byte array into signum representation
        BigInteger number = new BigInteger(1, hash);
        // Convert message digest into hex value
        StringBuilder hexString = new StringBuilder(number.toString(10));

        // Pad with leading zeros
        while (hexString.length() < 32)
        {
            hexString.insert(0, '0');
        }
        return hexString.toString();
    }

    public int getSequentialID() {
        return sequentialID;
    }

    public void setSequentialID(int sequentialID) {
        this.sequentialID = sequentialID;
    }
}
