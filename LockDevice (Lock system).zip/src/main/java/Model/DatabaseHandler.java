package Model;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.lockdevice.MainActivity;

import Utilities.Utilities;

public class DatabaseHandler extends SQLiteOpenHelper {


    public DatabaseHandler(Context context) {
        super(context , Utilities.DATABASE_NAME,  null, Utilities.DATABASE_VERSION);

    }
    public DatabaseHandler(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase DB) {

        String CREATE_TABLE_1 = "CREATE TABLE " + Utilities.TABLE_1 + "( " + Utilities.PRODUCT_NO + " TEXT NOT NULL UNIQUE" + " )";

        String CREATE_TABLE_2 = "CREATE TABLE " + Utilities.TABLE_2 + "( " + Utilities.OWNER_ID + " INTEGER PRIMARY KEY, " +
                Utilities.PASS + " TEXT NOT NULL UNIQUE, " + Utilities.PHONE + " INTEGER NOT NULL UNIQUE, "  + Utilities.OWNER_STATUS + " TEXT NOT NULL, " +
                 Utilities.USERNAME + " TEXT NOT NULL UNIQUE, " + Utilities.OWNER_PRODUCT + " TEXT NOT NULL UNIQUE" +")";

        DB.execSQL(CREATE_TABLE_1);
        DB.execSQL(CREATE_TABLE_2);
    }

    @Override
    public void onUpgrade(SQLiteDatabase DB, int i, int i1) {
        DB.execSQL("DROP TABLE IF EXISTS " + Utilities.TABLE_1);
        DB.execSQL("DROP TABLE IF EXISTS " + Utilities.TABLE_2);
        onCreate(DB);
    }

    public boolean checkIfOwnerExist(String ID , String product){

        int id = Integer.parseInt(ID);
        SQLiteDatabase DB = this.getReadableDatabase();
        Cursor cursor = DB.query(Utilities.TABLE_2,
                new String[]{Utilities.OWNER_ID, Utilities.OWNER_PRODUCT},
                Utilities.OWNER_ID + "=?",new String[]{ID},
                null,null,null,null);

        if(cursor != null){
            cursor.moveToFirst();
            String Id = cursor.getString(0);
            String produc_no = cursor.getString(1);
            if(Id.equalsIgnoreCase(ID) && product.equalsIgnoreCase(produc_no))
                return true;
        }


        return false;
    }

    public boolean productEqual(String product){


        return true;
    }

    public void addProduct(String prod){
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(Utilities.PRODUCT_NO, prod);

        DB.insert(Utilities.TABLE_1, null, contentValues);
        DB.close();

    }
    public String getProduct(){
        SQLiteDatabase DB = this.getReadableDatabase();
       // Cursor cursor = DB.query(Utilities.TABLE_1 ,Utilities.PRODUCT_NO,null,null,null,null);
        Cursor cursor = DB.query(Utilities.TABLE_1 , new String[]{Utilities.PRODUCT_NO}, null,
                null,null,null,null);

        cursor.moveToFirst();
        String product_num = cursor.getString(0);


        //String query = "select * from LockInfo";
        //Cursor cursor = DB.rawQuery(query, null);

        // Cursor cursor = DB.rawQuery("select id, Fname, Lname, Username, Phonenumber from USERS where Username=?", new String[] {username});
        return product_num;
    }


}
