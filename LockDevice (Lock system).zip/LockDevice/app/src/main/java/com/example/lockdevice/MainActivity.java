package com.example.lockdevice;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;

import Model.DatabaseHandler;

public class MainActivity extends AppCompatActivity {


    Button prime;
    Button scanQR;
    Button add_temp;
    Button addSecond;
    public static String [] productNumbers = {"666888","123666","123777","123888","123555"};
    public static ArrayList<primeOwner> OwnedLock = new ArrayList<primeOwner>();


    public DatabaseHandler DB  = new DatabaseHandler(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_screen);

        //DB.addProduct("123555");
        //DB.addProduct("123666");
        //DB.addProduct("123777");
        //DB.addProduct("123888");
        //DB.addProduct("666888");
        //for test
        OwnedLock.add(new primeOwner("666888","544295","666544#"));
        OwnedLock.add(new primeOwner("123555","544295","123544#"));


        prime = findViewById(R.id.prime_key);
        prime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"Welcome", Toast.LENGTH_SHORT).show();
                Intent prime = new Intent(MainActivity.this, primeOwner.class);
                startActivity(prime);
            }
        });


        addSecond = (Button) findViewById(R.id.add_secondary);
        addSecond.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent secondary = new Intent(MainActivity.this, secondaryOwner.class);
                startActivity(secondary);
            }
        });


        add_temp = (Button)findViewById(R.id.add_temp_user);
        add_temp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent secondary = new Intent(MainActivity.this, temporaryUser.class);
                startActivity(secondary);
            }
        });


        //set Up prime Owner
        scanQR = findViewById(R.id.scan_button);
        scanQR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                IntentIntegrator intentIntegrator = new IntentIntegrator(MainActivity.this);

                intentIntegrator.setPrompt("for flash use volume up key");

                intentIntegrator.setBeepEnabled(true);

                intentIntegrator.setOrientationLocked(true);

                intentIntegrator.setCaptureActivity(Capture.class);

                intentIntegrator.initiateScan();

            }
        });
        //open scanner page

        //after scanner display activation code

        //key have been added succefully



    }

    //check if Owner table empty
    //DB.checkIfOwnerExist();
    //check if product number equal of exist one
    //DB.productEqual();
    //get the product number from DB + ID from QR
    //DB.getProduct();
    //use SHA + OTP
    public String generateActivation(String content) throws NoSuchAlgorithmException {
        String line[] = content.split(" ");
        String productNum = line[0];
        String id = line[1];
        String userName = line[2];
        String phone = line[3];
       if(productEqual(productNum))
         if(checkIfOwnerExist(id , productNum)){
                primeOwner prime = new primeOwner(productNum,id,userName,phone);
                String num1 = prime.getProduct_NO().substring(0,3);
                String num2 = prime.getUserid().substring(0,3);
                String sharedSecret = num1 + num2 + "#";
                String secretKey = toHexString(getSHA(sharedSecret));
                prime.setPassword(sharedSecret);
                //Add to DB
                OwnedLock.add(prime);
                //int decimal=Integer.parseInt(secretKey,16);
                //byte[] b = getSHA(secretKey);
                //String t = toHexString(b);
                String nu = secretKey.substring(0,19);
                long d = Long.parseLong(nu);
                double dd = d %  Math.pow(10, 6);
                int i = (int) dd;
                String code = i + "";
                return code;
            }else{
                return "This Lock already have an owner";
            }
        return "Wrong Product number.";
    }

    public static boolean checkIfOwnerExist(String id, String number){
        boolean exist=true;
        for(int i = 0 ; i < OwnedLock.size()-1 ; i++){
            if(OwnedLock.get(i).getProduct_NO().equalsIgnoreCase(number)){
                if(OwnedLock.get(i).getUserid().equalsIgnoreCase(id)){
                    exist=false;
                }
            }
        }
        return exist;
    }

    public boolean productEqual(String number){
        boolean equal=false;
        for(int i = 0 ; i < productNumbers.length ; i++){
            if(productNumbers[i].equalsIgnoreCase(number)){
                equal=true;
            }
        }
        return equal;
    }






    public static byte[] getSHA(String secretKey) throws NoSuchAlgorithmException, NoSuchAlgorithmException {
        // Static getInstance method is called with hashing SHA
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        // digest() method called
        // to calculate message digest of an input
        // and return array of byte
        return md.digest(secretKey.getBytes());
    }

    public static String toHexString(byte[] hash)
    {
        // Convert byte array into signum representation
        BigInteger number = new BigInteger(1, hash);
        // Convert message digest into hex value
        StringBuilder hexString = new StringBuilder(number.toString(10));

        // Pad with leading zeros
        while (hexString.length() < 32)
        {
            hexString.insert(0, '0');
        }
        return hexString.toString();
    }




    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        IntentResult intentResult = IntentIntegrator.parseActivityResult(requestCode,resultCode,data);

        if(intentResult.getContents() != null){

            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);

            builder.setTitle("Activation code");

            String QRcontent = intentResult.getContents();

           // builder.setMessage(intentResult.getContents());

            //set activation code
          try {
              builder.setMessage(generateActivation(QRcontent));
          } catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
          }


            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                }
            });

            builder.show();

        }else{

            Toast.makeText(getApplicationContext(), "OOPS .. You didn't scan anything", Toast.LENGTH_SHORT).show();

        }

    }


}