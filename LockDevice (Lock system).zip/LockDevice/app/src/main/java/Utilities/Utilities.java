package Utilities;

public class Utilities {

    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "LockDevice";
    public static final String TABLE_1 = "LockInfo";
    public static final String PRODUCT_NO ="Product_no";
    public static final String TABLE_2 ="OwnerInfo";
    public static final String OWNER_ID ="OwnerID";
    public static final String PASS ="SharedSecret";
    public static final String PHONE ="Phone_num";
    public static final String OWNER_STATUS ="Status"; //exist not exist, active not active
    public static final String OWNER_PRODUCT ="ProductNo_Owner";
    public static final String USERNAME ="Username";

    public static final String TABLE_3 = "TempUsers";
    public static final String user_name ="Product_no";
    public static final String time ="OwnerInfo";
    public static final String date ="OwnerID";
    public static final String public_key ="SharedSecret";
    public static final String owner_id ="Phone_num";
    public static final String access_status ="Status"; //exist not exist, active not active


}
