package com.example.mykey;

import junit.framework.TestCase;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Test;

import static org.junit.Assert.assertTrue;

public class MainActivityTest extends TestCase {

    public void testOnCreate() {
    }

    public void testPerformSignUp() {

    }




}