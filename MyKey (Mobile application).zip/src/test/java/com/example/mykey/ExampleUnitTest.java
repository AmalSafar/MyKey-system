package com.example.mykey;

import android.app.Application;
import android.content.Context;

import org.junit.Test;

import Controller.DatabaseHandler;

import static org.junit.Assert.*;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    @Test
    public void addition_isCorrect() {
        assertEquals(4, 2 + 2);
    }



    @Test
    public void addUser(){
        String fname = "Raghad";
        String lanme ="Hisham";
        String userName ="rghadH";
        String pass = "123456789";
        String confPass = "123456789";
        String email = "raghad@gmail.com";
        long phone = 05676766565;
        MainActivity m = new MainActivity();
        m.addNewUser(fname , lanme, userName,pass,confPass,email,phone);

        assertTrue(true);


    }


}

