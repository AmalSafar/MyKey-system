package com.example.mykey;

import junit.framework.TestCase;

import org.junit.Test;

import Controller.DatabaseHandler;

import static org.junit.Assert.assertTrue;

public class MainActivityTest extends TestCase {

    public void testOnCreate() {

    }

    public void testLogInverified() {
        String fname = "Raghad";
        String lanme ="Hisham";
        String userName ="rghadH";
        String pass = "123456789";
        String confPass = "123456789";
        String email = "raghad@gmail.com";
        long phone = 05676766565;
        assertTrue(true);

    }

    public void testPerformSignUp() {
        String fname = "Raghad";
        String lanme ="Hisham";
        String userName ="rghadH";
        String pass = "123456789";
        String confPass = "123456789";
        String email = "raghad@gmail.com";
        long phone = 05676766565;
        assertTrue(true);

    }



}