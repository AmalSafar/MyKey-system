package Controller;

import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;

import com.example.mykey.Key;
import com.example.mykey.MainActivity;
import com.example.mykey.accessGenerator;

import java.lang.reflect.Array;
import java.util.ArrayList;

import Model.User;
import Model.primaryOwner;
import Model.secondaryOwner;
import Model.tempUser;
import Model.temproaryUser;
import Utilities.Utilities;

import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;


public class DatabaseHandler extends SQLiteOpenHelper {
    public DatabaseHandler( Context context) {
        super(context , Utilities.DATABASE_NAME,  null, Utilities.DATABASE_VERSION);

    }
    public DatabaseHandler(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }




    @Override
    public void onCreate(SQLiteDatabase DB) {

        // USERS
        String CREATE_USERS_TABLE = "CREATE TABLE " + Utilities.USERS_TABLE + "( " + Utilities.USER_ID + " INTEGER PRIMARY KEY, " +
                Utilities.USER_FNAME + " TEXT NOT NULL, " + Utilities.USER_LNAME + " TEXT NOT NULL, " + Utilities.USER_USERNAME + " TEXT NOT NULL UNIQUE, " +
                Utilities.USER_PASS + " TEXT NOT NULL, " + Utilities.USER_CONFPASS + " TEXT NOT NULL, " + Utilities.USER_EMAIL + " TEXT NOT NULL, " +
                Utilities.USER_PHONE + " INTEGER NOT NULL, " + Utilities.USER_PK + " TEXT " + ")";

        //KEYS TABLE
        String CREATE_KEY_TABLE = "CREATE TABLE " + Utilities.KEYS_TABLE + "( " + Utilities.KEY_ID + " INTEGER PRIMARY KEY, " +
                Utilities.KEY_NAME + " TEXT NOT NULL UNIQUE, " + Utilities.PASSWORD + " TEXT NOT NULL UNIQUE, " + Utilities.OWNER_ID  + " INTEGER references "
                + Utilities.USERS_TABLE +"("+  Utilities.USER_ID +"))";

        // OWNED LOCKS
        String CREATE_OWNED_KEY_TABLE = "CREATE TABLE " + Utilities.OWNED_KEYS + "( " + Utilities.OWNED_KEYS_owner + " INTEGER references " + Utilities.USERS_TABLE +"("+  Utilities.USER_ID +")," +
                Utilities.OWNED_KEYS_Key + " TEXT NOT NULL UNIQUE references "+Utilities.KEYS_TABLE+"("+  Utilities.KEY_ID +"),"
                + Utilities.OWNED_KEYS_KeyNAme + " TEXT NOT NULL UNIQUE," + Utilities.USER_PRODUCT + " TEXT NOT NULL UNIQUE)";


        // TEMP USER
        String CREATE_TEMPUSER_TABLE =
                "CREATE TABLE " + Utilities.TEMP_USER_TABLE + "( " + Utilities.Temp_ID + " INTEGER PRIMARY KEY, " + Utilities.user_name + " TEXT NOT NULL UNIQUE,"
                + Utilities.temp_pk +" TEXT NOT NULL UNIQUE " + ")";// can replace it with provide access table

        // PROVIDE ACCESS                             //YYYY-MM-DDTHH:MM:SS.SSS
        String CREATE_PROVIDE_ACCESS_TABLE = "CREATE TABLE " + Utilities.PROVIDE_ACCESS_TABLE + "( " + Utilities.OwnerId_temp  + " INTEGER references "
                + Utilities.USERS_TABLE +"("+  Utilities.USER_ID +"), " + Utilities.temp_id + " INTEGER references "
                + Utilities.TEMP_USER_TABLE +"("+  Utilities.Temp_ID +")," + Utilities.temp_username + " TEXT NOT NULL, " + Utilities.user_type + " TEXT NOT NULL, " + Utilities.shared_key + " TEXT NOT NULL, " + Utilities.date_of_access_from + " TEXT NOT NULL, "
                + Utilities.date_of_access_to + " TEXT NOT NULL, "+ Utilities.time_of_access_from + " TEXT NOT NULL, " +Utilities.time_of_access_to + " TEXT NOT NULL, "
                + Utilities.access_status + " BOOLEAN NOT NULL, " + Utilities.access_type + " TEXT NOT NULL"+")";


        //REPORT
        String CREATE_REPORT_TABLE = "CREATE TABLE " + Utilities.REPORTS_TABLE + "( " + Utilities.REPORT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                Utilities.TEMP_ID + " TEXT NOT NULL UNIQUE, " + Utilities.ENTER_TIME + " DATE NOT NULL, " + Utilities.EXIT_TIME  + " DATE NOT NULL,"+ Utilities.DATE +" DATE NOT NULL," +
                Utilities.QR_VALIDATION+" TEXT NOT NULL UNIQUE"+")";


        //SECONDARY OWNER
        String CREATE_SET_OWNER_TABLE = "CREATE TABLE " + Utilities.SET_SECONDARY_OWNER_TABLE + "( " + Utilities.Seondary_Id + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                Utilities.Seondary_username + " TEXT NOT NULL UNIQUE, " + Utilities.KeyId_sec + " TEXT NOT NULL, " + Utilities.Sec_Email  + " TEXT NOT NULL, " + Utilities.accessType + " TEXT NOT NULL, " +
                Utilities.OwnerId_sec  + " INTEGER references " + Utilities.USERS_TABLE +"("+  Utilities.USER_ID +" ))";//will have current owner ID with secondary ID

        //String CREATE_GETLOGS_TABLE = "CREATE TABLE " + Utilities.GET_LOGS_TABLE + "( " + Utilities.KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
        //      Utilities.KEY_NAME + " TEXT NOT NULL UNIQUE, " + Utilities.PASSWORD + " TEXT NOT NULL, " + Utilities.OWNER_ID  + " )";//owner ID, Report ID, date


        DB.execSQL(CREATE_USERS_TABLE);
                DB.execSQL(CREATE_KEY_TABLE);
                DB.execSQL(CREATE_PROVIDE_ACCESS_TABLE);
                DB.execSQL(CREATE_TEMPUSER_TABLE);
                DB.execSQL(CREATE_REPORT_TABLE);
                DB.execSQL(CREATE_OWNED_KEY_TABLE);
                DB.execSQL(CREATE_SET_OWNER_TABLE);
    }
    @Override
    public void onUpgrade(SQLiteDatabase DB, int i, int i1) {
        DB.execSQL("DROP TABLE IF EXISTS " + Utilities.USERS_TABLE);
        DB.execSQL("DROP TABLE IF EXISTS " + Utilities.KEYS_TABLE);
        DB.execSQL("DROP TABLE IF EXISTS " + Utilities.REPORTS_TABLE);
        DB.execSQL("DROP TABLE IF EXISTS " + Utilities.OWNED_KEYS);
        DB.execSQL("DROP TABLE IF EXISTS " + Utilities.PROVIDE_ACCESS_TABLE);
        DB.execSQL("DROP TABLE IF EXISTS " + Utilities.TEMP_USER_TABLE);
        DB.execSQL("DROP TABLE IF EXISTS " + Utilities.SET_SECONDARY_OWNER_TABLE);
        onCreate(DB);
    }

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public void addUser (User user){
        //add new user to DB
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(Utilities.USER_ID, user.getID());
        contentValues.put(Utilities.USER_FNAME, user.getFirstName());
        contentValues.put(Utilities.USER_LNAME, user.getLastName());
        contentValues.put(Utilities.USER_USERNAME, user.getUserName());
        contentValues.put(Utilities.USER_PASS, user.getPassword());
        contentValues.put(Utilities.USER_CONFPASS, user.getConfPassword());
        contentValues.put(Utilities.USER_EMAIL, user.getEmail());
        contentValues.put(Utilities.USER_PHONE, user.getPhoneNumber());
        contentValues.put(Utilities.USER_PK, "");
        DB.insert(Utilities.USERS_TABLE, null, contentValues);
        DB.close();
    }

    public void addSecondaryOwner (secondaryOwner secondOwner){

        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(Utilities.Seondary_Id, secondOwner.getSequentialID());
        contentValues.put(Utilities.Seondary_username, secondOwner.getUserName());
        contentValues.put(Utilities.KeyId_sec, secondOwner.getKey());
        contentValues.put(Utilities.Sec_Email, secondOwner.getEmail());
        contentValues.put(Utilities.accessType, secondOwner.getAccess_type());
        contentValues.put(Utilities.OwnerId_sec, MainActivity.CurrentUserName);
        DB.insert(Utilities.SET_SECONDARY_OWNER_TABLE, null, contentValues);
        DB.close();

    }

    public void addTempUser (temproaryUser user , String userType){


        //adding the information to Provide access table
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(Utilities.OwnerId_temp, MainActivity.CurrentUserName);
        contentValues.put(Utilities.temp_id, user.getSequentialID());
        contentValues.put(Utilities.temp_username, user.getUserName());
        contentValues.put(Utilities.user_type, user.getUserType());
        contentValues.put(Utilities.date_of_access_from, user.getDateFrom());
        contentValues.put(Utilities.date_of_access_to, user.getDateTo());
        contentValues.put(Utilities.time_of_access_to, user.getExitTime());
        contentValues.put(Utilities.time_of_access_from, user.getEnteranceTime());
        contentValues.put(Utilities.access_status, "valid");
        contentValues.put(Utilities.shared_key, user.getKeyName());
        contentValues.put(Utilities.access_type, user.getAccessType());
        DB.insert(Utilities.PROVIDE_ACCESS_TABLE, null, contentValues);
        DB.close();

    }


    public void displayReport (User user){
        //add new user to DB

     //   DB.insert(Utilities.REPORTS_TABLE, null, contentValues);
     //   DB.close();
    }

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public void addOwnedLock (String product , String OwnerID , int KeyID , String KeyName){
        //add new user to DB
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(Utilities.OWNED_KEYS_owner, OwnerID);
        contentValues.put(Utilities.OWNED_KEYS_Key, KeyID);
        contentValues.put( Utilities.OWNED_KEYS_KeyNAme, KeyName);
        contentValues.put(Utilities.USER_PRODUCT, product);
        DB.insert(Utilities.OWNED_KEYS, null, contentValues);
        DB.close();
    }

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public ArrayList<String> getOwnedLock(String username) {

        SQLiteDatabase DB = this.getReadableDatabase();
        Cursor cursor = DB.query(Utilities.USERS_TABLE,
                new String[]{Utilities.USER_ID, Utilities.USER_USERNAME,},
                Utilities.USER_USERNAME + "=?", new String[]{username},
                null, null, null, null);
        cursor.moveToFirst();
        String userID = cursor.getString(0);

        Cursor cursor1 = DB.query(Utilities.KEYS_TABLE,
                new String[]{Utilities.KEY_ID, Utilities.KEY_NAME, Utilities.PASSWORD, Utilities.OWNER_ID},
                Utilities.OWNER_ID + "=?", new String[]{userID},
                null, null, null, null);


        ArrayList<String> LockNames = new ArrayList<>();

        try {
            if (cursor1 != null) {
                cursor1.moveToFirst();
                do {
                    LockNames.add(cursor1.getString(1));
                } while (cursor1.moveToNext());
                return LockNames;
            }
        }catch(Exception e){
                e.printStackTrace();
            } finally{
                if (cursor != null && !cursor.isClosed()) {
                    cursor.close();
                }
            }
        return LockNames;
    }


    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public ArrayList<Key> getKeys(String username) {
        SQLiteDatabase DB = this.getReadableDatabase();
        Cursor cursor = DB.query(Utilities.USERS_TABLE,
                new String[]{Utilities.USER_ID, Utilities.USER_USERNAME,},
                Utilities.USER_USERNAME + "=?", new String[]{username},
                null, null, null, null);
        cursor.moveToFirst();
        String userID = cursor.getString(0);

        Cursor cursor1 = DB.query(Utilities.KEYS_TABLE,
                new String[]{Utilities.KEY_ID, Utilities.KEY_NAME, Utilities.PASSWORD, Utilities.OWNER_ID},
                Utilities.OWNER_ID + "=?", new String[]{userID},
                null, null, null, null);


        ArrayList<Key> keyList = new ArrayList<Key>();
        Key key = null;
        if (cursor1 != null) {
            cursor1.moveToFirst();
            do {
                key = new Key();
                key.setKeyID(Integer.parseInt(cursor1.getString(0)));
                key.setKeyName(cursor1.getString(1));
                key.setPasswordKey(cursor1.getString(2));
                key.setOwnerID(cursor1.getString(3));
                keyList.add(key);
            } while (cursor1.moveToNext());

            return keyList;
        }
        return keyList;
    }



    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public boolean verifyUser (String username, String pass) {
        //add new user to DB
        SQLiteDatabase DB = this.getReadableDatabase();
        Cursor cursor = DB.query(Utilities.USERS_TABLE,
                new String[]{Utilities.USER_USERNAME, Utilities.USER_PASS},
                Utilities.USER_USERNAME + "=?", new String[]{username},
                null, null, null, null);

        try {
            if (cursor != null) {
                cursor.moveToFirst();
                String user = cursor.getString(0);
                String password = cursor.getString(1);
                if (user.equalsIgnoreCase(username) && password.equalsIgnoreCase(pass))
                    return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
        }
        return false;
    }
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void addKey (Key key){
            //link the owner with key or lock
            SQLiteDatabase DB = this.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put(Utilities.KEY_ID, key.getKeyID());
            contentValues.put(Utilities.KEY_NAME, key.getKeyName());
            contentValues.put(Utilities.PASSWORD, key.getPasswordKey());
            contentValues.put(Utilities.OWNER_ID, key.getOwnerID());
            DB.insert(Utilities.KEYS_TABLE, null, contentValues);
            DB.close();
        }



        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public primaryOwner getCurrentUser (String username){
            SQLiteDatabase DB = this.getReadableDatabase();
            Cursor cursor = DB.query(Utilities.USERS_TABLE,
                    new String[]{Utilities.USER_ID, Utilities.USER_FNAME, Utilities.USER_LNAME,
                            Utilities.USER_USERNAME,
                            Utilities.USER_PHONE},
                    Utilities.USER_USERNAME + "=?", new String[]{username},
                    null, null, null, null);


            if (cursor != null)
                cursor.moveToFirst();
            primaryOwner po = new primaryOwner(cursor.getString(0), cursor.getString(3), cursor.getString(4));
            return po;
        }


    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public ArrayList<primaryOwner> getOwendLockInfo (String username){
        SQLiteDatabase DB = this.getReadableDatabase();
        Cursor cursor = DB.query(Utilities.USERS_TABLE,
                new String[]{Utilities.USER_ID},
                Utilities.USER_USERNAME + "=?", new String[]{username},
                null, null, null, null);


        cursor.moveToFirst();
        String userID = cursor.getString(0);

        Cursor cursor1 = DB.query(Utilities.OWNED_KEYS,
                new String[]{Utilities.OWNED_KEYS_owner, Utilities.USER_PRODUCT, Utilities.OWNED_KEYS_KeyNAme},
                Utilities.OWNED_KEYS_owner + "=?", new String[]{userID},
                null, null, null, null);


        ArrayList<primaryOwner> Locks = new ArrayList<primaryOwner>();
        primaryOwner prime = null;
        if (cursor1 != null) {
            cursor1.moveToFirst();
            do {
                prime = new primaryOwner();
                prime.setUserid(cursor1.getString(0) );
                prime.setProduct_NO( cursor1.getString(1));
                prime.setKeyName( cursor1.getString(2));
                Locks.add(prime);
            } while (cursor1.moveToNext());

            return Locks;
        }
        return Locks;
    }

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public ArrayList<temproaryUser> getProvideAccess (){
            SQLiteDatabase DB = this.getReadableDatabase();
            Cursor cursor = DB.query(Utilities.USERS_TABLE,
                    new String[]{Utilities.USER_ID, Utilities.USER_USERNAME,},
                    Utilities.USER_USERNAME + "=?", new String[]{MainActivity.CurrentUserName},
                    null, null, null, null);
            cursor.moveToFirst();
            String userID = cursor.getString(0);

            Cursor cursor1 = DB.query(Utilities.PROVIDE_ACCESS_TABLE,
                    new String[]{ Utilities.temp_id, Utilities.temp_username, Utilities.user_type,
                            Utilities.date_of_access_from,Utilities.date_of_access_to,Utilities.time_of_access_from,Utilities.time_of_access_to,Utilities.access_status,
                            Utilities.shared_key,Utilities.access_type},
                    Utilities.OwnerId_temp + "=?", new String[]{MainActivity.CurrentUserName},
                    null, null, null, null);


            ArrayList<temproaryUser> tempUsers = new ArrayList<temproaryUser>();
            temproaryUser temp = null;
            if (cursor1 != null) {
                cursor1.moveToFirst();
                do {
                    temp = new temproaryUser();
                    temp.setSequentialID(Integer.parseInt(cursor1.getString(0)));
                    temp.setUserName(cursor1.getString(1));
                    temp.setUserType(cursor1.getString(2));
                    temp.setDateFrom(cursor1.getString(3));
                    temp.setDateTo(cursor1.getString(4));
                    temp.setEnteranceTime(cursor1.getString(5));
                    temp.setExitTime(cursor1.getString(6));
                    temp.setAccessStatus(cursor1.getString(7));
                    temp.setKeyName(cursor1.getString(8));
                    temp.setAccessType(cursor1.getString(9));
                    tempUsers.add(temp);
                } while (cursor1.moveToNext());

                return tempUsers;
            }
            return tempUsers;

    }
    }


