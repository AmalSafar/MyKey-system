package Model;

import androidx.appcompat.app.AppCompatActivity;

import com.example.mykey.Key;
import com.example.mykey.accessGenerator;

import java.sql.Date;

public class remoteUser extends temproaryUser {

    private String userName;
    private Key key;
    private accessGenerator tempAccess;
    private Date TimeStamp;
    private Date enteranceTime;
    private Date exitTime;
    private Date dateFrom;
    private Date dateTo;
    private Key sparekey;


    public remoteUser() {
        super();
        this.key = key;
    }

    public remoteUser(String userName, Key key, accessGenerator tempAccess, Date timeStamp, Date enteranceTime, Date exitTime, Date dateFrom, Date dateTo) {
        super();
        this.userName = userName;
        this.key = key;
        this.tempAccess = tempAccess;
        TimeStamp = timeStamp;
        this.enteranceTime = enteranceTime;
        this.exitTime = exitTime;
        this.dateFrom = dateFrom;
        this.dateTo = dateTo;
    }

    public accessGenerator generatAccess(){
        //get from DB the spare key or from key's array
        //
        accessGenerator access = new accessGenerator();


        return access;
    }

}
