package Model;


import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.IntentSender;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.UserHandle;
import android.text.TextUtils;
import android.view.Display;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import Controller.DatabaseHandler;
import com.example.mykey.Key;
import com.example.mykey.MainActivity;
import com.example.mykey.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.regex.Pattern;

public class primaryOwner extends AppCompatActivity {

    private String publicKey;
    private String product_NO;
    private String userid;
    private String username;
    private String sharedSecret;
    private String phonenumber;
    private String KeyName;
    private ArrayList<String> KeyOwned;
    private ArrayList<secondaryOwner> SecondOwners;
    DatabaseHandler DB = new DatabaseHandler(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Lock page to add new lock for primary owner
        setContentView(R.layout.my_locks);
        getSupportActionBar().setTitle("My Locks");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        //call method to display all locks
        displayLocks();


        BottomNavigationView bottomNav = findViewById(R.id.nav_bar);
        bottomNav.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.key_page:
                        startActivity(new Intent(getApplicationContext(), Key.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.home__page:
                        startActivity(new Intent(getApplicationContext(), com.example.mykey.homePage.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.profile_page:
                        startActivity(new Intent(getApplicationContext(), User.class));
                        overridePendingTransition(0,0);
                        return true;
                }
                return false;
            }
        });

        ImageView secondOwner = (ImageView)findViewById(R.id.add_secondary);
        secondOwner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent secOwner = new Intent (primaryOwner.this, secondaryOwner.class);
                startActivity(secOwner);
            }
        });


        //The process to add new lock
        TextView newLock = (TextView) findViewById(R.id.Add_New_Lock);
        newLock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setContentView(R.layout.setup_productno);
                Button addKey = (Button)findViewById(R.id.addKey);
                addKey.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        EditText productNo = (EditText)findViewById(R.id.product_No);
                        Toast.makeText(getApplicationContext()," Please enter product number ", Toast.LENGTH_SHORT).show();
                        //check the filed is not empty
                        if(TextUtils.isEmpty(productNo.getText().toString())){
                            Toast.makeText(getApplicationContext()," Please enter product number ", Toast.LENGTH_SHORT).show();
                            productNo.setError("Required");
                        } else{
                            //check if the product number not contain character (only numbers)
                            if(!(productNo.getText().toString().matches("^[0-9]*$"))  && !(productNo.getText().toString().length() ==6) ){
                                productNo.setError("Invalid product number!, must be numbers only and 6 digits");
                            }else{

                                //after validate product number
                                String productNum = productNo.getText().toString();
                                InfoQR(productNum);

                                //after invoke method (InfoQR)
                                Button done = (Button) findViewById(R.id.Scanned_button);
                                done.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        setContentView(R.layout.setup_owned_lock);
                                        getSupportActionBar().setTitle("Key Setup");
                                        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
                                        Button activation_button = (Button)findViewById(R.id.activation_button);
                                        activation_button.setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View view) {

                                                //Must enter the activation code appeared on the screen
                                                EditText editTextactivation = (EditText)findViewById(R.id.activation_code);
                                                if(TextUtils.isEmpty(editTextactivation.getText().toString())){
                                                    editTextactivation.setError("Required");
                                                } else{
                                                    if(editTextactivation.getText().toString().matches("^[a-zA-Z]*$") && (editTextactivation.getText().toString().length() != 6)){
                                                        editTextactivation.setError("Invalid code");
                                                    }else{

                                                        //after validate the activation code
                                                        String activation = editTextactivation.getText().toString();
                                                        try {

                                                            //verify the code is correct
                                                            if(activationProcess(activation)){
                                                                Toast.makeText(getApplicationContext()," Activation code is valid! ", Toast.LENGTH_SHORT).show();
                                                                setContentView(R.layout.key_settings);
                                                                    Button Finish_button = (Button) findViewById(R.id.Finish_button);
                                                                    Finish_button.setOnClickListener(new View.OnClickListener() {
                                                                        @Override
                                                                        public void onClick(View view) {
                                                                            EditText keyName = (EditText)findViewById(R.id.key_name);
                                                                            if(TextUtils.isEmpty(keyName.getText().toString())){
                                                                                keyName.setError("Required");
                                                                            }else{
                                                                                String KeyNAme = keyName.getText().toString();
                                                                                //increament the counter of owned locks or keys
                                                                                int keySeq =com.example.mykey.Key.counter;
                                                                                Key key = new Key (keySeq , KeyNAme, getSharedSecret() , getUserid() );
                                                                                //add the new lock to Database tables to be retrived later
                                                                                DB.addKey(key);
                                                                                DB.addOwnedLock(getProduct_NO(),getUserid(),keySeq, KeyNAme);
                                                                                com.example.mykey.Key.setCounter(++com.example.mykey.Key.counter);
                                                                                setContentView(R.layout.confirmed_lock);
                                                                                //press button to go back to home
                                                                                Button go_home = (Button)findViewById(R.id.back_to_home);
                                                                                go_home.setOnClickListener(new View.OnClickListener() {
                                                                                    @Override
                                                                                    public void onClick(View view) {
                                                                                        Toast.makeText(getApplicationContext(),"successfully added", Toast.LENGTH_SHORT).show();
                                                                                        Intent done = new Intent (primaryOwner.this, com.example.mykey.homePage.class);
                                                                                        startActivity(done);
                                                                                        finish();
                                                                                    }
                                                                                });
                                                                            }


                                                                        }


                                                                    });


                                                                //add to DB key, owend key,
                                                            }else{
                                                                Toast.makeText(getApplicationContext()," Activation process failed, please try again", Toast.LENGTH_SHORT).show();
                                                            }
                                                        } catch (NoSuchAlgorithmException e) {
                                                            e.printStackTrace();
                                                        }
                                                    }
                                                }

                                            }
                                        });
                                    }
                                });
                            }

                        }
                    }
                });
            }
        });
    }

    public primaryOwner( String userid, String username, String phonenumber) {
        this.userid = userid;
        this.username = username;
        this.phonenumber = phonenumber;
    }

    public primaryOwner( String userid, String product_NO) {
        this.userid = userid;
        this.product_NO = product_NO;

    }
    public primaryOwner( ) {


    }
    public String regestartion() {
        //TODO implement here
        return null;
    }

    public String generateQR() {
        // TODO implement here
        return null;
    }


    public String getSharedSecret() {
        return sharedSecret;
    }

    public void setSharedSecret(String sharedSecret) {
        this.sharedSecret = sharedSecret;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
    }



    public void displayLocks() {
        this.KeyOwned = DB.getOwnedLock(MainActivity.CurrentUserName);
        if (KeyOwned.size() != 0) {
            String[] KeyName = new String[KeyOwned.size()];
            for (int i = 0; i < this.KeyOwned.size(); i++) {
                KeyName[i] = this.KeyOwned.get(i);
            }
            ListView listView = (ListView) findViewById(R.id.Lock_List);
            ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, KeyName);
            listView.setAdapter(arrayAdapter);
        }
    }

    public boolean activationProcess(String activationCode) throws NoSuchAlgorithmException {
        //generate the shared secret and activation code to verify it synchronized with lock
        String num1 = getProduct_NO().substring(0,3);
        String num2 = getUserid().substring(0,3);
        String sharedSecret = num1 + num2 + "#";
        //invoke the encryption method to encrypt the secret key and generate one time password
        String secretKey = toHexString(getSHA(sharedSecret));
        //the proccess of generating one time password to be compared with activation code
        String nu = secretKey.substring(0,19);
        long convertToLong = Long.parseLong(nu);
        double otp = convertToLong %  Math.pow(10, 6);
        int OTP = (int) otp;
        String code = OTP+"";
        if (code.equalsIgnoreCase(activationCode)) {
           //setSharedSecret(code);
            this.sharedSecret= sharedSecret;
            Toast.makeText(getApplicationContext(),"true" + OTP, Toast.LENGTH_SHORT).show();
            return true;
        }else{
            Toast.makeText(getApplicationContext()," not equal " + OTP, Toast.LENGTH_SHORT).show();
            return false;
        }
    }
    public static byte[] getSHA(String secretKey) throws NoSuchAlgorithmException, NoSuchAlgorithmException {
        // Static getInstance method is called with hashing SHA
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        // digest() method called
        // to calculate message digest of an input
        // and return array of byte
        return md.digest(secretKey.getBytes());
    }
    public static String toHexString(byte[] hash)
    {
        // Convert byte array into signum representation
        BigInteger number = new BigInteger(1, hash);
        // Convert message digest into hex value
        StringBuilder hexString = new StringBuilder(number.toString(10));

        // Pad with leading zeros
        while (hexString.length() < 32)
        {
            hexString.insert(0, '0');
        }
        return hexString.toString();
    }


    public void InfoQR(String productNo){

        String info = productNo;
        // get primary owner info + product num to create QR
        primaryOwner primary = DB.getCurrentUser(MainActivity.CurrentUserName);
        this.product_NO = productNo;
        this.userid = primary.getUserid();
        primary.setProduct_NO(productNo);
        info += " " + primary.getUserid()+" "+ primary.getUsername()+" "+primary.getPhonenumber();

        MultiFormatWriter writer = new MultiFormatWriter();
        try{
            BitMatrix matrix = writer.encode(info , BarcodeFormat.QR_CODE, 350 , 350);
            BarcodeEncoder encoder = new BarcodeEncoder();
            Bitmap bitmap = encoder.createBitmap(matrix);
            setContentView(R.layout.qr_page);
            ImageView infoQR = (ImageView) findViewById(R.id.qr_output);
            infoQR.setImageBitmap(bitmap);
        }catch (WriterException e) {
            e.printStackTrace();
        }
        }



    public String getProduct_NO() {
        return product_NO;
    }

    public void setProduct_NO(String product_NO) {
        this.product_NO = product_NO;

    }

    public void disableLock(){


    }
    public void setOwner(){


    }

    public String getKeyName() {
        return KeyName;
    }

    public void setKeyName(String keyName) {
        KeyName = keyName;
    }

    public void revokeOwner(secondaryOwner owner, Key keyID){


    }
}
