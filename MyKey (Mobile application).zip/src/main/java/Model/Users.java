package Model;

public interface Users {

   // private String email;
    //private String password;
    //private String confPassword;
    //private String lastName;
    //private String userType;
    //private long phoneNumber;
    //private String userName;

    /**
     * @return
     */
    public String regestartion();

    /**
     * @return
     */
    public String logIn();

    /**
     * @return
     */
    public String logOut();


}
