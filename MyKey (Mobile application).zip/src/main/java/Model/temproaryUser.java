package Model;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.mykey.MainActivity;
import com.example.mykey.R;
import com.example.mykey.accessGenerator;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder;

import java.security.NoSuchAlgorithmException;
import java.sql.Date;
import java.util.ArrayList;

import Controller.DatabaseHandler;

public class temproaryUser extends AppCompatActivity {


    private String access_type;
    private String userName;
    private String KeyName;
    private String enteranceTime;
    private String exitTime;
    private String dateFrom;
    private String dateTo;
    private String accessStatus;
    private tempUser temp;
    private remoteUser remote;
    private String userType;
    private String accessInfo;
    private RadioButton userTypeRemote ;
    private RadioButton userTypeTemp ;
    private int sequentialID ;
    private boolean tempUser;
    private boolean remotUser;
    private temproaryUser temproaryUser;
    DatabaseHandler DB = new DatabaseHandler(this);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.share_key_temp);

        getSupportActionBar().setTitle("Share Key");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Button shareButton = (Button)findViewById(R.id.select_shareable_user);
        shareButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                userTypeRemote = (RadioButton) findViewById(R.id.select_remote);
                userTypeTemp = (RadioButton) findViewById(R.id.select_temp);

                if(userTypeTemp.isChecked()){
                    setTempUser(true);
                }else if(userTypeRemote.isChecked()){
                    setRemotUser(true);
                }

                setContentView(R.layout.share_key);
                showAllLocks();
                getSupportActionBar().setTitle("Share Key");
                Button share = (Button) findViewById(R.id.Share_key_button);
                share.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        EditText username = (EditText) findViewById(R.id.username);
                        EditText dateF = (EditText) findViewById(R.id.Date_from);
                        EditText dateT = (EditText) findViewById(R.id.Date_to);
                        EditText enterTime = (EditText) findViewById(R.id.enter_time);
                        EditText exitTime = (EditText) findViewById(R.id.exit_time);
                        Switch accessType = (Switch) findViewById(R.id.switch2);

                        String userName = username.getText().toString();
                        String dateFrom = dateF.getText().toString();
                        String dateTo = dateT.getText().toString();
                        String enter_Time = enterTime.getText().toString();
                        String exit_Time = exitTime.getText().toString();
                        String access_type = accessType.getTextOn().toString();
                        String selectedKey = showAllLocks();

                        if(accessType.isClickable()){
                            access_type="limited";
                        }else{
                            access_type="open";
                        }

                        temproaryUser = new temproaryUser( userName, selectedKey, enter_Time, exit_Time, dateFrom, dateTo,access_type);
                        temproaryUser.setKeyName(selectedKey);
                        accessInfo = InfoQR(selectedKey);
                        accessInfo += " " +userName+" "+dateFrom+" " +dateTo+" "+enter_Time+" "+exit_Time+" "+access_type+" ";

                        if (tempUser == true) {
                            userType = "TemporaryUser";
                            accessInfo += userType;
                            temp = new tempUser(temproaryUser.getUserName(), temproaryUser.getKeyName(), temproaryUser.getEnteranceTime(), temproaryUser.getExitTime(), temproaryUser.dateFrom, temproaryUser.getDateTo(),temproaryUser.getAccessType());
                            setTemp(temp);
                            generateTempQR(accessInfo);
                        //QR
                        Button done = (Button) findViewById(R.id.Scanned_button);
                        done.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                setContentView(R.layout.activation_code);
                                Button button = (Button) findViewById(R.id.finish_activate);
                                button.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        EditText activationCode = (EditText) findViewById(R.id.activation_field);
                                        String Code = activationCode.getText().toString();
                                        //check for equalization
                                        //show error message and go to home page
                                        try {
                                            if (activationProcess(Code)) {
                                                //the information of temporary user and access must be added to DB
                                                DB.addTempUser(temproaryUser,userType);
                                                //in this part the key will be shared by RSA encryption using public key of temporary user
                                                setContentView(R.layout.request_successed);
                                                Button back = (Button) findViewById(R.id.back_button);
                                                back.setOnClickListener(new View.OnClickListener() {
                                                    @Override
                                                    public void onClick(View view) {
                                                        Intent Finish = new Intent(temproaryUser.this, com.example.mykey.homePage.class);
                                                        startActivity(Finish);
                                                        finish();
                                                    }
                                                });
                                            } else {
                                                Toast.makeText(getApplicationContext(), "Sorry, Temporary User cannot be added!", Toast.LENGTH_SHORT).show();
                                            }
                                        } catch (NoSuchAlgorithmException e) {
                                            e.printStackTrace();
                                        }
                                    }
                                });
                                Button backHome= (Button)findViewById(R.id.back_home);
                                backHome.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        Intent done = new Intent(temproaryUser.this, com.example.mykey.homePage.class);
                                        startActivity(done);
                                        finish();
                                    }
                                });
                            }
                        });
                    }


                    if (remotUser) {
                        userType = "RemoteUser";
                        accessInfo += userType;
                        //on this process we will use RSA encryption that allow to exchange keys securely
                        accessGenerator accessGenerator = new accessGenerator();
                        accessGenerator.generateRemoteQR("remote");
                        DB.addTempUser(temproaryUser,userType);
                        setContentView(R.layout.request_successed);
                        Button back = (Button) findViewById(R.id.back_button);
                        back.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Intent Finish = new Intent(temproaryUser.this, com.example.mykey.homePage.class);
                                startActivity(Finish);
                                finish();
                            }
                        });


                    }

                    }
                });

            }
        });
    }


    public temproaryUser(String userName, String keyName, String enteranceTime, String exitTime, String dateFrom, String dateTo, String accessType) {
        this.sequentialID +=1;
        this.userName = userName;
        this.access_type = accessType;
        this.KeyName = keyName;
        this.enteranceTime = enteranceTime;
        this.exitTime = exitTime;
        this.dateFrom = dateFrom;
        this.dateTo = dateTo;

    }

    public boolean isTempUser() {
        return tempUser;
    }

    public void setTempUser(boolean tempUser) {
        this.tempUser = tempUser;
    }

    public boolean isRemotUser() {
        return remotUser;
    }

    public void setRemotUser(boolean remotUser) {
        this.remotUser = remotUser;
    }

    public tempUser getTemp() {
        return temp;
    }

    public void setTemp(tempUser temp) {
        this.temp = temp;
    }

    public temproaryUser() {
        //get the key password
    }

    public int getSequentialID() {
        return sequentialID;
    }

    public void setSequentialID(int sequentialID) {
        this.sequentialID = sequentialID;
    }

    public boolean activationProcess(String activationCode) throws NoSuchAlgorithmException {

        String information = accessInfo;
        Toast.makeText(getApplicationContext(),information, Toast.LENGTH_SHORT).show();
        String encryptedInfo = primaryOwner.toHexString(primaryOwner.getSHA(information));
        String code1 = encryptedInfo.substring(0,19);
        long OTP1 = Long.parseLong(code1);
        double dd = OTP1 %  Math.pow(10, 6);
        int OTP = (int) dd;
        String code = OTP+"";
        if (code.equalsIgnoreCase(activationCode)) {
            // setSharedSecret(code);
            Toast.makeText(getApplicationContext(),"true" + OTP, Toast.LENGTH_SHORT).show();
            return true;
        }else{
            Toast.makeText(getApplicationContext()," not equal " + OTP, Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    public String showAllLocks(){

        ArrayList<String> names = new ArrayList<>();
        Spinner spinner = (Spinner)findViewById(R.id.Key_list);
        names = DB.getOwnedLock(MainActivity.CurrentUserName);
        if (names.size() != 0) {
            String[] KeyName = new String[names.size()];
            for (int i = 0; i < names.size(); i++) {
                KeyName[i] = names.get(i);
            }
            ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, names);
            // MyAdapter adapter = new MyAdapter(this, mTitle, mDescription, images);
            arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(arrayAdapter);
            String item = (String) spinner.getSelectedItem();
            return item;
        }

       return "";
    }

    public String InfoQR(String selectedKey){

        String info ="";
        ArrayList<primaryOwner> prime = DB.getOwendLockInfo(MainActivity.CurrentUserName);
        for(int i = 0 ; i < prime.size() ; i++){
            if(prime.get(i).getKeyName().equalsIgnoreCase(selectedKey)){
                info +=  prime.get(i).getProduct_NO()+" "+ prime.get(i).getUserid();
            }
        }
        Toast.makeText(getApplicationContext(),info +" temp ", Toast.LENGTH_LONG).show();

        return info;

    }
    public void generateTempQR(String accessInfo){
        //for temproray user, must link with Database to check privilges
        MultiFormatWriter writer = new MultiFormatWriter();
        try {
            BitMatrix matrix = writer.encode(accessInfo, BarcodeFormat.QR_CODE, 350, 350);
            BarcodeEncoder encoder = new BarcodeEncoder();
            Bitmap bitmap = encoder.createBitmap(matrix);
            setContentView(R.layout.qr_page);
            ImageView infoQR = (ImageView) findViewById(R.id.qr_output);
            infoQR.setImageBitmap(bitmap);

        } catch (WriterException e) {
            e.printStackTrace();
        }

    }

    public String getUserName() {
        return userName;
    }

    public String getEnteranceTime() {
        return enteranceTime;
    }

    public String getExitTime() {
        return exitTime;
    }

    public String getDateFrom() {
        return dateFrom;
    }

    public String getDateTo() {
        return dateTo;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setEnteranceTime(String enteranceTime) {
        this.enteranceTime = enteranceTime;
    }

    public String getKeyName() {
        return KeyName;
    }

    public void setKeyName(String keyName) {
        KeyName = keyName;
    }

    public String getAccessType() {
        return access_type;
    }

    public void setAccessType(String access_type) {
        this.access_type = access_type;
    }

    public String getAccessStatus() {
        return accessStatus;
    }

    public void setAccessStatus(String accessStatus) {
        this.accessStatus = accessStatus;
    }

    public void setExitTime(String exitTime) {
        this.exitTime = exitTime;
    }

    public void setDateFrom(String dateFrom) {
        this.dateFrom = dateFrom;
    }

    public void setDateTo(String dateTo) {
        this.dateTo = dateTo;
    }

    /**
     * @return
     */
}
