package Model;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.widget.EditText;
import android.view.*;
import android.widget.ImageView;


import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

import javax.crypto.*;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import Controller.DatabaseHandler;

import com.example.mykey.Key;
import com.example.mykey.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.Random;

public class User extends AppCompatActivity {

    private String email;
    private int ID;
    private String password;
    private String confPassword;
    private String firstName;
    private String lastName;
    private long phoneNumber;
    private String userName;
    private String publicKey;
    private final int PASSWORD_LENGTH = 8;
    private User currUsers;
    private Random rnd = new Random();
    private byte[] text;
    private Cipher AES;
    private Cipher RSA;
    private PrivateKey PV;
    private PublicKey PK;
    private KeyPair myPair;
    private IvParameterSpec ivspec ;
    private SecretKeySpec secretKeySpec;
    DatabaseHandler DB = new DatabaseHandler(this);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile_page);
        //Toolbar myToolbar = (Toolbar) findViewById(R.id.tool_bar_);
        //setSupportActionBar(myToolbar);
        getSupportActionBar().setTitle("My Profile");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        BottomNavigationView bottomNav = findViewById(R.id.nav_bar);
        bottomNav.setSelectedItemId(R.id.profile_page);
        bottomNav.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.key_page:
                        startActivity(new Intent(getApplicationContext(), Key.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.home__page:
                        startActivity(new Intent(getApplicationContext(), com.example.mykey.homePage.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.profile_page:
                        return true;
                }
                return false;
            }
        });

        ImageView Report = (ImageView)findViewById(R.id.report);
        Report.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(User.this, com.example.mykey.Report.class);
                startActivity(intent);
            }
        });

        ImageView logOut = (ImageView)findViewById(R.id.log_out);
        logOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(User.this, com.example.mykey.MainActivity.class);
                startActivity(intent);
                finish();

            }
        });

        // just for login user or could be for signed up user
        // get the user name
        // go to DB invoke method
        // select query (user that have this user name
        // insert all info in setting page and create an object
        // invoke DB and retreive all info of current user then display home page
        // retreive all the exist key for this user and added to the page
        // retrive this user public key
        // create object to be used
        // DB.getKeys(); return all his key owned and temp
        // if method return null >> don't have then skip or break the if statment
        // DB.getUser(); return user info and his public key
        // if method return null >> don't have then skip or break the if statment
       // this.currUsers = new User();


    }
    public User() {
    }

    public User(String password, String userName) {
        this.password = password;
        this.userName = userName;
    }

    public User(String email, String password, String confPassword, String firstName, String lastName, long phoneNumber, String userName) throws NoSuchPaddingException, NoSuchAlgorithmException {
            this.email = email;
            this.ID = rnd.nextInt(999999);
            this.password = password;
            this.confPassword = confPassword;
            this.firstName = firstName;
            this.lastName = lastName;
            this.phoneNumber = phoneNumber;
            this.userName = userName;
            this.AES = Cipher.getInstance("AES/CBC/PKCS5Padding");


            this.RSA = Cipher.getInstance("RSA");
            KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");
            this.myPair = generator.generateKeyPair();
            this.PK = myPair.getPublic();
            this.PV = myPair.getPrivate();

            byte[] iv = new byte[16];
            this.ivspec = new IvParameterSpec(iv);


        }

    public void setPK(PublicKey PK) {
        this.PK = PK;
    }

    public String getPkString(){

        //convert the publick Key to string then store in DB


        return null;

    }
    public PublicKey getPK() throws NoSuchAlgorithmException, InvalidKeySpecException {

        //get the key from DB

        byte[] pk = PK.getEncoded();
        String p = new String(pk);
        byte[] p1 = p.getBytes();
        byte[] privateKeyBytes;
        byte[] publicKeyBytes;
        KeyFactory kf = KeyFactory.getInstance("RSA"); // or "EC" or whatever
        PrivateKey privateKey = kf.generatePrivate(new PKCS8EncodedKeySpec(p1));
        PublicKey publicKey = kf.generatePublic(new X509EncodedKeySpec(p1));


        setPK(publicKey);

        return publicKey;
    }

    public PrivateKey getPV() {
        return PV;
        }

    // Checking if the input in form is valid
        public boolean checkFileds(EditText fname , EditText lname , EditText userName , EditText email, EditText password , EditText confPass , EditText phone) {

        boolean check = true;

            if(TextUtils.isEmpty(fname.getText().toString())){
                fname.setError("Required");
                check = false;
            }

            if(TextUtils.isEmpty(lname.getText().toString())){
                lname.setError("");
                check = false;
            }

            if(TextUtils.isEmpty(userName.getText().toString())){
                userName.setError("");
                check = false;
            }
            if(TextUtils.isEmpty(email.getText().toString())){
                email.setError("");
                check = false;
            }
            if(TextUtils.isEmpty(password.getText().toString())){
                password.setError("");
                check = false;
            }
            if(TextUtils.isEmpty(confPass.getText().toString())){
                confPass.setError("");
                check = false;
            }
            if(TextUtils.isEmpty(phone.getText().toString())){
                phone.setError("");
                check = false;
            }

            /*
            if (Fname.equals("")) {
                fname.setError("Please Enter First Name");
                check = false;
            }
            if (lname.getText().toString().equals("")) {
                lname.setError("Please Enter Last Name");
                check = false;
            }
            if (email.getText().toString().equals("")) {
                email.setError("Please Enter Email");
                check = false;
            }
            if (password.getText().toString().equals("")) {
                password.setError("Please Enter Password");
                check = false;
            }
            if (confPass.getText().toString().equals("")) {
                confPass.setError("Please Enter Repeat Password");
                check = false;
            }
            // checking the proper email format
            if (!isEmailValid(Email)) {
                email.setError("Please Enter Valid Email");
                check = false;
            }
            // checking minimum password Length

            // Checking if repeat password is same

            */
            if (password.getText().length() < PASSWORD_LENGTH) {
                password.setError("Password Length must be more than " + PASSWORD_LENGTH + " characters");
                check = false;
            }

            if (!password.getText().toString().equals(confPass.getText().toString())) {
                confPass.setError("Password does not match");
                check = false;
            }
            return check;

        }


        boolean isEmailValid(String email) {
            return Patterns.EMAIL_ADDRESS.matcher(email).matches();
        }





        public void setEmail(String email) {
            this.email = email;
        }

        public void setID(int ID) {
            this.ID = ID;
        }

        public void setPassword(String password) {
            this.password = password;
        }

        public void setConfPassword(String confPassword) {
            this.confPassword = confPassword;
        }

        public void setFirstName(String firstName) {
            this.firstName = firstName;
        }

        public void setLastName(String lastName) {
            this.lastName = lastName;
        }

        public void setPhoneNumber(long phoneNumber) {
            this.phoneNumber = phoneNumber;
        }

        public void setUserName(String userName) {
            this.userName = userName;
        }

        public String getEmail() {
            return email;
        }

        public int getID() {
            return ID;
        }

        public String getPassword() {
            return password;
        }

        public String getConfPassword() {
            return confPassword;
        }

        public String getFirstName() {
            return firstName;
        }

        public String getLastName() {
            return lastName;
        }

        public long getPhoneNumber() {
            return phoneNumber;
        }

        public String getUserName() {
            return userName;
        }

         public String getPublicKey() {
            return publicKey;
         }

         public User getCurrUser() {
            return currUsers;
         }
}
