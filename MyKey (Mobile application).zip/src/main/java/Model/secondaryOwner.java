package Model;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;

import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Toast;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.mykey.Key;
import com.example.mykey.MainActivity;
import com.example.mykey.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;

import Controller.DatabaseHandler;

public class secondaryOwner extends AppCompatActivity {
    /**
     * Default constructor
     */
    private String userName;
    private long phone ;
    private String email;
    private String access_type;
    private String Key;
    private int sequentialID = 0;
    private String spareKey[];
    private String info;
    private secondaryOwner second;
    DatabaseHandler DB = new DatabaseHandler(this);



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.add_secondary);
        showAllLocks();
        getSupportActionBar().setTitle("Add Secondary Owner");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Button setOwner = (Button) findViewById(R.id.set_owner);
        setOwner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                EditText username = (EditText) findViewById(R.id.secondaryUserName);
                EditText phone = (EditText) findViewById(R.id.secondary_phone);
                EditText email = (EditText) findViewById(R.id.secondary_email);
                RadioButton Permanent = (RadioButton) findViewById(R.id.Permanent_radio);
                RadioButton Temporary = (RadioButton) findViewById(R.id.TemporaryRadio);

                String userName = username.getText().toString();
                String Phone = phone.getText().toString();
                long num = Long.parseLong(Phone);
                String Email = email.getText().toString();
                //get the selected key from (showAllLocks()) method that he want to setted to secondary owner
                String selectedKey = showAllLocks();
                String access_type = "Permanent";

                if(Permanent.isChecked()){
                    access_type = "Permanent";
                }

                if(Temporary.isChecked()){
                    access_type = "Temporary";
                }

                //create secondary owner object to be inserted on database
                secondaryOwner secondary_Owner = new secondaryOwner(userName,num,Email,access_type,selectedKey);
                setSecond(secondary_Owner);
                Toast.makeText(getApplicationContext(),secondary_Owner.getSequentialID()+" sequent ", Toast.LENGTH_SHORT).show();
                //generate QR (contains required information)
                info = InfoQR(selectedKey);
                info += " " + userName + " " + Phone + " " + Email + " " + selectedKey + " " + access_type + " " + secondary_Owner.getSequentialID();
                Toast.makeText(getApplicationContext(),info, Toast.LENGTH_SHORT).show();
                Toast.makeText(getApplicationContext(),MainActivity.CurrentUserName+" secondary ", Toast.LENGTH_LONG).show();
                MultiFormatWriter writer = new MultiFormatWriter();
                try{
                    BitMatrix matrix = writer.encode(info , BarcodeFormat.QR_CODE, 350 , 350);
                    BarcodeEncoder encoder = new BarcodeEncoder();
                    Bitmap bitmap = encoder.createBitmap(matrix);
                    setContentView(R.layout.qr_page);
                    ImageView infoQR = (ImageView) findViewById(R.id.qr_output);
                    infoQR.setImageBitmap(bitmap);

                }catch (WriterException e) {
                    e.printStackTrace();
                }

                Button done = (Button) findViewById(R.id.Scanned_button);
                done.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        setContentView(R.layout.activation_code);
                        Button button = (Button)findViewById(R.id.finish_activate);
                        button.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                EditText activationCode = (EditText)findViewById(R.id.activation_field);
                                String Code = activationCode.getText().toString();
                                //check for equalization
                                //show error message and go to home page
                                try {
                                    if(activationProcess(Code)){
                                        //confirmation Page
                                        //add new owner to database
                                        DB.addSecondaryOwner(getSecond());
                                        Toast.makeText(getApplicationContext(),getSecond().sequentialID + " Secondary Owner added successfully", Toast.LENGTH_SHORT).show();
                                        setContentView(R.layout.request_successed);
                                        Button back = (Button)findViewById(R.id.back_button);
                                        back.setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View view) {
                                                Intent Finish = new Intent (secondaryOwner.this, primaryOwner.class);
                                                startActivity(Finish);
                                                finish();
                                            }
                                        });
                                    }else{
                                        Toast.makeText(getApplicationContext(),"Sorry, secondary owner cannot be added!", Toast.LENGTH_SHORT).show();
                                    }
                                } catch (NoSuchAlgorithmException e) {
                                    e.printStackTrace();
                                }
                            }
                        });

                        Button home = (Button)findViewById(R.id.back_home);
                        home.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Intent Finish = new Intent (secondaryOwner.this, primaryOwner.class);
                                startActivity(Finish);
                                finish();
                            }
                        });
                    }
                });
            }

        });

        BottomNavigationView bottomNavigationView = findViewById(R.id.nav_bar);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()){
                    case R.id.key_page:
                        startActivity(new Intent(getApplicationContext(),Key.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.home__page:
                        startActivity(new Intent(getApplicationContext(), MainActivity.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.profile_page:
                        startActivity(new Intent(getApplicationContext(), User.class));
                        overridePendingTransition(0,0);
                        return true;
                }
                return false;

            }
        });

    }

    public secondaryOwner() {

    }
    public secondaryOwner(String userName , long phone , String email , String access , String Key ) {
        this.sequentialID += 1;
        this.userName = userName;
        this.phone = phone;
        this.email = email;
        this.access_type = access;
        this.Key = Key;
    }

    /**
     * @return
     */

    public int getSequentialID() {
        return sequentialID;
    }

    public void setSequentialID(int sequentialID) {
        this.sequentialID = sequentialID;
    }

    public boolean activationProcess(String activationCode) throws NoSuchAlgorithmException {

        // on this method an OTP will be generated to be compared with the code entered
        String information = info;
        Toast.makeText(getApplicationContext(),information, Toast.LENGTH_SHORT).show();
        String encryptedInfo = toHexString(getSHA(information));
        String code1 = encryptedInfo.substring(0,19);
        long OTP1 = Long.parseLong(code1);
        double dd = OTP1 %  Math.pow(10, 6);
        int OTP = (int) dd;
        String code = OTP+"";
        if (code.equalsIgnoreCase(activationCode)) {
            Toast.makeText(getApplicationContext(),"true" + OTP, Toast.LENGTH_SHORT).show();
            return true;
        }else{
            Toast.makeText(getApplicationContext()," not equal " + OTP, Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    public static byte[] getSHA(String secretKey) throws NoSuchAlgorithmException, NoSuchAlgorithmException {
        // Static getInstance method is called with hashing SHA
        MessageDigest md = MessageDigest.getInstance("SHA-256");

        // digest() method called
        // to calculate message digest of an input
        // and return array of byte
        return md.digest(secretKey.getBytes());
    }

    public static String toHexString(byte[] hash)
    {
        // Convert byte array into signum representation
        BigInteger number = new BigInteger(1, hash);
        // Convert message digest into hex value
        StringBuilder hexString = new StringBuilder(number.toString(10));

        // Pad with leading zeros
        while (hexString.length() < 32)
        {
            hexString.insert(0, '0');
        }
        return hexString.toString();
    }


    public String InfoQR(String selectedKey){

        String info ="";
        ArrayList<primaryOwner> prime = DB.getOwendLockInfo(MainActivity.CurrentUserName);

        for(int i = 0 ; i < prime.size() ; i++){
            if(prime.get(i).getKeyName().equalsIgnoreCase(selectedKey)){
                info +=  prime.get(i).getProduct_NO()+" "+ prime.get(i).getUserid();
            }
        }
        Toast.makeText(getApplicationContext(),info +" secondary ", Toast.LENGTH_LONG).show();

       return info;

    }

    public String showAllLocks(){
        ArrayList<String> names = new ArrayList<>();
        Spinner spinner = (Spinner)findViewById(R.id.Lock_list);
        names = DB.getOwnedLock(MainActivity.CurrentUserName);
        if (names.size() != 0) {
            String[] KeyName = new String[names.size()];
            for (int i = 0; i < names.size(); i++) {
                KeyName[i] = names.get(i);
            }
            ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, names);
            // MyAdapter adapter = new MyAdapter(this, mTitle, mDescription, images);
            arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(arrayAdapter);
            String item = (String) spinner.getSelectedItem();
            return item;
        }
        return "";
    }




    public String regestartion() {
        // TODO implement here
        return null;
    }


    public secondaryOwner getSecond() {
        return second;
    }

    public void setSecond(secondaryOwner second) {
        this.second = second;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public long getPhone() {
        return phone;
    }

    public void setPhone(long phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAccess_type() {
        return access_type;
    }

    public void setAccess_type(String access_type) {
        this.access_type = access_type;
    }

    public String getKey() {
        return Key;
    }

    public void setKey(String key) {
        Key = key;
    }
}
