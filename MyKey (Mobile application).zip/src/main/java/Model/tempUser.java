package Model;

import com.example.mykey.Key;
import com.example.mykey.accessGenerator;

import java.sql.Date;

public class tempUser extends temproaryUser {
    private String userName;
    private String key;
    private String tempAccess;
    private String enteranceTime;
    private String exitTime;
    private String dateFrom;
    private String dateTo;
    private String accessType;
    private String userType;

    public tempUser() {
        super();
        this.key = key;
    }
    public tempUser(String userName, String key, String dateFrom, String dateTo ,String enteranceTime, String exitTime, String tempAccess) {
        this.userType = "TemporaryUser";
        this.userName = userName;
        this.key = key;
        this.tempAccess = tempAccess;
        this.enteranceTime = enteranceTime;
        this.exitTime = exitTime;
        this.dateFrom = dateFrom;
        this.dateTo = dateTo;

    }

    @Override
    public String getUserType() {
        return userType;
    }

    @Override
    public void setUserType(String userType) {
        this.userType = userType;
    }
}
