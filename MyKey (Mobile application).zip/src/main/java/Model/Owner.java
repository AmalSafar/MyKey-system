package Model;
import com.example.mykey.Key;
import com.example.mykey.Report;
import java.util.Date;

public abstract class Owner implements Users {

    private String productNum;
    private String activeCode;
    private String spareKey[];
    private temproaryUser tempUsers[];

    public Owner() {
    }
    public void creatTempProfile(tempUser newUser, String enteranceTime, Date date, String userName) {
        // TODO implement here
    }
    public void creatRemoteProfile(remoteUser newUser, String enteranceTime, Date date, String userName) {
        // TODO implement here
    }
    public Report requestReport() {
        // TODO implement here
        return null;
    }
    public boolean revokeAccess(Users user, String userName) {
        // TODO implement here
        return false;
    }
    public Key disableKey() {
        // TODO implement here
        return null;
    }
    /**
     * @return
     */
}
