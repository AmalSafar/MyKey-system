package Utilities;

public class Utilities {

    public static final int DATABASE_VERSION = 3;
    public static final String DATABASE_NAME = "MyKey.db";
    public static final String USERS_TABLE = "USERS";
    public static final String USER_ID ="id";
    public static final String USER_FNAME ="Fname";
    public static final String USER_LNAME ="Lname";
    public static final String USER_USERNAME ="Username";
    public static final String USER_PASS ="Password";
    public static final String USER_CONFPASS ="Confpassword";
    public static final String USER_EMAIL ="Email";
    public static final String USER_PHONE ="Phonenumber";
    public static final String USER_PRODUCT ="Product_no";
    public static final String USER_PK ="public_key";


    public static final String KEYS_TABLE = "Keys";
    public static final String KEY_ID ="keyID";
    public static final String KEY_NAME ="keyName";
    public static final String SPARE_KEYS ="spareKey";
    public static final String PASSWORD ="passsword";
    public static final String OwnerId_own ="owner_id";

    public static final String REPORTS_TABLE = "Reports";
    public static final String REPORT_ID ="SerialNumber";
    public static final String TEMP_ID ="temp_id";
    public static final String ENTER_TIME ="enter_time";
    public static final String EXIT_TIME ="exit_time";
    public static final String DATE ="date";
    public static final String QR_VALIDATION ="QR_valid";



    public static final String SET_SECONDARY_OWNER_TABLE = "Set_Owner";
    public static final String OwnerId_sec = "owner_username";
    public static final String Seondary_Id = "SeondaryOwner_Id";
    public static final String Seondary_username = "userName";
    public static final String KeyId_sec = "SharedLock"; // or lock, product number
    public static final String Sec_Email = "Secondary_email"; // or lock, product number
    public static final String accessType = "Period_of_Access"; // or lock, product number

    public static final String TEMP_USER_TABLE = "temp_user";
    public static final String Temp_ID = "Temp_ID"; //seq by owner
    public static final String user_name = "user_name";
    public static final String temp_pk = "tempUser_PK";

    public static final String PROVIDE_ACCESS_TABLE = "ProvideAccess";
    public static final String OwnerId_temp = "owner_id"; //refrences
    public static final String temp_id = "temp_id"; // refrences
    public static final String temp_username = "temp_username";
    public static final String user_type = "user_type"; //temp, remote
    public static final String date_of_access_from = "date_from";
    public static final String date_of_access_to = "date_to";
    public static final String time_of_access_from = "time_from";
    public static final String time_of_access_to = "time_to";
    public static final String access_status = "access_status";
    public static final String shared_key = "keyTEXT";
    public static final String access_type = "access_type";

    public static final String ADD_OWNER_TABLE = "Owner";
    public static final String OWNER_ID = "owner_id";
    public static final String  PHONE = "Phone_Num";
    public static final String KeyId_own = "key_id";
    public static final String Product_NUM = "Product_No";

    public static final String OWNED_KEYS = "Owned_Keys";
    public static final String OWNED_KEYS_owner = "owner_ID";
    public static final String OWNED_KEYS_Key = "Key_ID";
    public static final String OWNED_KEYS_KeyNAme = "Key_Name";





}
