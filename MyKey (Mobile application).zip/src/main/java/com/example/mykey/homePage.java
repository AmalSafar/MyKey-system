package com.example.mykey;


import android.content.ClipData;
import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import Model.User;

public class homePage extends AppCompatActivity {

    //home page icons
    private ImageView mylocks ;
    private ImageView shareKey ;
    private ImageView keyStatus ;
    private ImageView keyChain ;
    private ImageView homeImage;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Display home page
        setContentView(R.layout.home_page);
        getSupportActionBar().setTitle("My Key");
        BottomNavigationView bottomNavigationView = findViewById(R.id.nav_bar);
        bottomNavigationView.setSelectedItemId(R.id.home__page);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()){
                    case R.id.key_page:
                        startActivity(new Intent(getApplicationContext(),Key.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.home__page:
                        return true;
                    case R.id.profile_page:
                        startActivity(new Intent(getApplicationContext(),User.class));
                        overridePendingTransition(0,0);
                        return true;
                }
                return false;

            }
        });


        // home pag options
        mylocks = (ImageView) findViewById(R.id.lockImage);
        mylocks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //setContentView(R.layout.my_locks);
                Intent retreiveCurrData = new Intent(getApplicationContext(), Model.primaryOwner.class);
                startActivity(retreiveCurrData);
            }
        });
        shareKey = (ImageView) findViewById(R.id.shareKeyImage);
        shareKey.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent retreiveCurrData = new Intent(getApplicationContext(), Model.temproaryUser.class);
                startActivity(retreiveCurrData);
            }
        });
        keyStatus = (ImageView) findViewById(R.id.lockStatusImage);
        keyStatus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                     Intent retreiveCurrData = new Intent(getApplicationContext(), lockStatus.class);
                     startActivity(retreiveCurrData);
            }
        });
        keyChain = (ImageView) findViewById(R.id.keyChainImage);
        keyChain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent retreiveCurrData = new Intent(getApplicationContext(), Key.class);
                startActivity(retreiveCurrData);
            }
        });


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }



    @Override
    protected void onStart() {
        super.onStart();
    }

}
