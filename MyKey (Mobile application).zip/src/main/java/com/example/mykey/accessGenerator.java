package com.example.mykey;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.Toast;

import java.nio.charset.StandardCharsets;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.*;
import androidx.appcompat.app.AppCompatActivity;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder;

import java.sql.Date;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Locale;

import Model.primaryOwner;
import Model.remoteUser;
import Model.tempUser;
import Model.temproaryUser;

public class accessGenerator extends AppCompatActivity {

    private final int expireTime = 2;
    private boolean accessStatus = false;
    private int accessLimitaion ;
    private ImageView KeyQR;
    private String publicKey;//on this page the public key
    private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public accessGenerator() {
    }

    public accessGenerator(temproaryUser t) {

        tempUser temp = (tempUser) t;

    }

    public accessGenerator(boolean accessStatus, int accessLimitaion) {
        this.accessStatus = accessStatus;
        this.accessLimitaion = accessLimitaion;
    }

    public Bitmap generateQR(String pass) throws NoSuchAlgorithmException {

        // here we will get current time
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        String time = sdf.format(timestamp);

        String password = time+""+pass;
        // use SHA function
        String sharedSecret = toHexString(getSHA(password));
        String nu = sharedSecret.substring(0,18);
        long d = Long.parseLong(nu);
        double dd = d %  Math.pow(10, 6);
        int OTP = (int) dd;
        String code = OTP+"";
        // generate QR
        MultiFormatWriter writer = new MultiFormatWriter();
        try{
            BitMatrix matrix = writer.encode(code , BarcodeFormat.QR_CODE, 350 , 350);
            BarcodeEncoder encoder = new BarcodeEncoder();
            Bitmap bitmap = encoder.createBitmap(matrix);
            return bitmap;
        }catch (WriterException e) {
            e.printStackTrace();
        }
              return null;
    }

    public static byte[] getSHA(String secretKey) throws NoSuchAlgorithmException
    {
        // Static getInstance method is called with hashing SHA
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        return md.digest(secretKey.getBytes());
    }

    public static String toHexString(byte[] hash)
    {
        // Convert byte array into signum representation
        BigInteger number = new BigInteger(1, hash);
        // Convert message digest into hex value
        StringBuilder hexString = new StringBuilder(number.toString(10));

        // Pad with leading zeros
        while (hexString.length() < 32)
        {
            hexString.insert(0, '0');
        }
        return hexString.toString();
    }


    public void generateTempQR(String accessInfo){
        //for temproray user, must link with Database to check privilges
        MultiFormatWriter writer = new MultiFormatWriter();
        try {
            BitMatrix matrix = writer.encode(accessInfo, BarcodeFormat.QR_CODE, 350, 350);
            BarcodeEncoder encoder = new BarcodeEncoder();
            Bitmap bitmap = encoder.createBitmap(matrix);
            setContentView(R.layout.qr_page);
            ImageView infoQR = (ImageView) findViewById(R.id.qr_output);
            infoQR.setImageBitmap(bitmap);

        } catch (WriterException e) {
            e.printStackTrace();
        }

    }
    public void generateRemoteQR(String accessInfo){

        //use public key of specified remote user to generate an access for him to be shared with.

    }

    public boolean checkAccessStatus(boolean accessStatus, int accessLimitaion){
        // check for access time
        return false;
    }

}
