package com.example.mykey;

import androidx.annotation.NonNull;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.*;
import android.widget.EditText;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder;

import org.w3c.dom.Text;

import java.security.NoSuchAlgorithmException;

import javax.crypto.NoSuchPaddingException;

import Controller.DatabaseHandler;
import Model.User;
import Model.primaryOwner;
import Model.tempUser;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {


    private DatabaseHandler sqlLiteDBHandler;
    private SQLiteDatabase sqlite;
    private EditText editTextSerialNumberInsert;
    private EditText editTextSerialNumberFetch;
    private EditText editTextInsert;
    private TextView textViewDisplay;
    private TextView viewEmail;
    private TextView viewUserName;
    private EditText fname, lname, userName, email, pass, confPass, phone;
    private Button viewQR;
    private ImageView ouputQR;
    private Spinner keyItem;
    private EditText input;

    public static String CurrentUserName;

    private Button sign_up;
    private Button getStart;
    private Button signUp;
    //Navigation toolbar
    private ImageView KeyImage;
    private ImageView homeImage;
    private ImageView SettingImage;
    private RadioButton userTypeRemote;
    private RadioButton userTypeTemp;
    public DatabaseHandler DB  = new DatabaseHandler(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash_page);
        getSupportActionBar().hide();
        //open log in page
        getStart = (Button) findViewById(R.id.start);
        getStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setContentView(R.layout.login_page);
                getSupportActionBar().hide();
                //if log in pressed will go to User class to verify identity
                Button login = (Button)findViewById(R.id.LogInButton);
                login.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        User loginUser = new User();
                        EditText username = (EditText) findViewById(R.id.log_in_user);
                        EditText password = (EditText) findViewById(R.id.log_in_pass);
                        String userN = username.getText().toString();
                        String pass = password.getText().toString();
                        if(LogInverified(userN,pass)){
                            CurrentUserName = username.getText().toString();
                            Toast.makeText(getApplicationContext(),"Welcome", Toast.LENGTH_SHORT).show();
                            Intent retreiveCurrData = new Intent(MainActivity.this, homePage.class);
                            startActivity(retreiveCurrData);
                            finish();
                        }else{
                            Toast.makeText(getApplicationContext(),"Please check Your Username and Password", Toast.LENGTH_SHORT).show();

                        }
                    }
                });


                //create User obj with username and password and call login method
                // if press line that called sign up process will initate intent class and inside it call the meth

                TextView signUpLine = (TextView)findViewById(R.id.signUpLine);
                signUpLine.setOnClickListener(new View.OnClickListener(){
                    @Override
                    public void onClick(View view){
                        setContentView(R.layout.sign_up);
                        sign_up = (Button)findViewById(R.id.signupButton);
                        sign_up.setOnClickListener(new View.OnClickListener(){
                            @Override
                            public void onClick(View view) {

                                try {
                                    //invoke method perform sign up to insert new object to Database
                                    if(performSignUp(view)){
                                        Toast.makeText(getApplicationContext(),"sign up successfully "+CurrentUserName, Toast.LENGTH_SHORT).show();
                                        Intent retreiveCurrData = new Intent(MainActivity.this, homePage.class);
                                        startActivity(retreiveCurrData);
                                        finish();
                                    }else{
                                        //if fields empty, an error message occured
                                        Toast.makeText(getApplicationContext(),"Please fill the required fields", Toast.LENGTH_SHORT).show();

                                    }
                                } catch (NoSuchAlgorithmException e) {
                                    e.printStackTrace();
                                } catch (NoSuchPaddingException e) {
                                    e.printStackTrace();
                                }

                            }
                        });
                    }
                });
            }
        });
           /*
        */
    }

    /*
*/

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.tool_bar , menu);
        return super.onCreateOptionsMenu(menu);
    }


    public boolean LogInverified(String username , String pass){

        boolean verified = DB.verifyUser(username,pass);

        return verified;
    }

        public boolean performSignUp (View view) throws NoSuchAlgorithmException, NoSuchPaddingException {
        // object of user, inside call the method check fileds then retrun true or false
        // then if true take this object and insert it
        boolean valid= true;
        fname = (EditText)findViewById(R.id.Fname);
        lname = (EditText)findViewById(R.id.Lname);
        userName = (EditText)findViewById(R.id.userName);
        pass = (EditText)findViewById(R.id.password);
        confPass = (EditText)findViewById(R.id.confPass);
        email = (EditText)findViewById(R.id.email);
        phone = (EditText)findViewById(R.id.Phone);
        User newUser = new User();

        //call method checkfileds in user class
        boolean validation = newUser.checkFileds(fname ,lname , userName , email, pass , confPass , phone);

        if (validation==true) {
        // get the text
        String Fname = fname.getText().toString();
        String Lname = lname.getText().toString();
        String user_name = userName.getText().toString();
        String password = pass.getText().toString();
        String conf_pass = confPass.getText().toString();
        int Phone = Integer.parseInt(phone.getText().toString());
        String Email = email.getText().toString();
        User user = new User(Email,  password,  conf_pass,  Fname,  Lname ,  Phone,  user_name);
        DB.addUser(user);
            this.CurrentUserName = user_name ;

            valid = true;
        return valid;
        }else{
            valid =false;
        }
        return valid;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        fname = (EditText)findViewById(R.id.Fname);
        lname = (EditText)findViewById(R.id.Lname);
        userName = (EditText)findViewById(R.id.userName);
        pass = (EditText)findViewById(R.id.password);
        confPass = (EditText)findViewById(R.id.confPass);
        email = (EditText)findViewById(R.id.email);
        phone = (EditText)findViewById(R.id.Phone);
        User newUser = new User();

        boolean validation = newUser.checkFileds(fname ,lname , userName , email, pass , confPass , phone);

        if (validation==true) {
            // get the text
            String Fname = fname.getText().toString();
            String Lname = lname.getText().toString();
            String user_name = userName.getText().toString();
            String password = pass.getText().toString();
            String conf_pass = confPass.getText().toString();
            int Phone = Integer.parseInt(phone.getText().toString());
            String Email = email.getText().toString();
            User user = null;
            try {
                user = new User(Email,  password,  conf_pass,  Fname,  Lname ,  Phone,  user_name);
            } catch (NoSuchPaddingException e) {
                e.printStackTrace();
            } catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
            }
            DB.addUser(user);
            this.CurrentUserName = user_name ;

            // Input is valid, here send data to database
            // insert on DB then shoe the Home_page interface
            // if fileds correct create objects and retrun to then pass it to DB
            // take the user object, use get method to insert data on DB
        }
    }




    @Override
    public void onClick(View view) {
    }
}