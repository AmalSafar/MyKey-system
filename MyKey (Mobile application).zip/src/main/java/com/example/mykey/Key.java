package com.example.mykey;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Date;

import Controller.DatabaseHandler;
import Model.User;
import Model.primaryOwner;

public class Key extends AppCompatActivity {

    private int keyID;
    private String keyName;
    private String PasswordKey;
    private Date TimeStamp;
    private String [] spareKeys;
    private accessGenerator access;
    private primaryOwner prime;
    private String OwnerID;
    public static int counter = 1;
    private ListView KeyChainList;
    DatabaseHandler DB = new DatabaseHandler(this);
    private ArrayList<Key> keysList = new ArrayList<Key>();
    //retreive keys from DB depend on owner ID
    private EditText userName ;
    private String Owner;
    //from user setting page we will get the Text view (ID) then compare with it

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //pass ID to DB to retrive the keys

        setContentView(R.layout.keys_list_page);
        getSupportActionBar().setTitle("Key Chain");
        displayKeys();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        BottomNavigationView bottomNav = findViewById(R.id.nav_bar);
        bottomNav.setSelectedItemId(R.id.key_page);
        bottomNav.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.key_page:
                        return true;
                    case R.id.home__page:
                        startActivity(new Intent(getApplicationContext(),homePage.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.profile_page:
                        startActivity(new Intent(getApplicationContext(), User.class));
                        overridePendingTransition(0,0);
                        return true;
                }
                return false;
            }
        });

    }


    public Key() {
    }

    public Key(int keyID, String KeyName, String passwordKey, String[] spareKeys) {
        this.keyID = keyID;
        PasswordKey = passwordKey;
        this.spareKeys = spareKeys; //add spare keys now
        this.keyName = keyName;
    }

    public Key(int keyID, String KeyName, String passwordKey) {
        this.keyID = keyID;
        this.PasswordKey = passwordKey;

        this.keyName = keyName;
    }
    public Key(int keyID, String KeyName, String passwordKey , String OwnerID) {
        this.keyID = keyID;
        this.PasswordKey = passwordKey;
        this.keyName = KeyName;
        this.OwnerID=OwnerID;
    }

    public ArrayList<Key> getKeysList() {
        return keysList;
    }

    public void setKeysList(ArrayList<Key> keysList) {
        this.keysList = keysList;
    }

    public void displayKeys(){

        this.keysList = DB.getKeys(MainActivity.CurrentUserName);
        if(keysList.size() != 0){
            String [] KeyName = new String[keysList.size()];
            for(int i = 0 ; i < this.keysList.size(); i++){
                KeyName[i] = this.keysList.get(i).getKeyName();
            }

            //
            ListView listView=(ListView)findViewById(R.id.keyChain);
            ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,KeyName);
            listView.setAdapter(arrayAdapter);
           //select the required key from key chain, if pressed key information will be invoked and generate QR from secret Key
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                    for(int j = 0 ; j<keysList.size() ; j++){
                       if(i == j){
                            setContentView(R.layout.qr_page);
                            accessGenerator generateAccess = new accessGenerator();
                            try {
                                ImageView QR = (ImageView) findViewById(R.id.qr_output);
                                String s = getKeysList().get(j).getPasswordKey();
                                //generate QR to be scanned on the lock
                                //after encrypt the shared secret
                                QR.setImageBitmap(generateAccess.generateQR(s));
                                Toast.makeText(getApplicationContext(),s, Toast.LENGTH_SHORT).show();
                                Button done = (Button) findViewById(R.id.Scanned_button);
                                done.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        Intent done = new Intent (Key.this, com.example.mykey.homePage.class);
                                        startActivity(done);
                                        finish();
                                    }
                                });
                            } catch (NoSuchAlgorithmException e) {
                                e.printStackTrace();
                            }
                        }
                    }

                }
            });
        }



        //enter product number
        //create obj accessGenerator
        //call method and retrive QR then display it
        //after scanned display page activation code

        //create Key Obj added this obj to owner array and insert on DB
        // get user info + product num to create QR
        //for the owner
        //create the QR

    }

    public static int getCounter() {
        return counter;
    }

    public static void setCounter(int counter) {
        Key.counter = counter;
    }

    public Key searchKey(String keyID){
        return null;

    }
    public primaryOwner getPrime() {
        return prime;
    }

    public void setKeyID(int keyID) {
        this.keyID = keyID;
    }

    public void setKeyName(String keyName) {
        this.keyName = keyName;
    }

    public void setPasswordKey(String passwordKey) {
        PasswordKey = passwordKey;
    }

    public void setTimeStamp(Date timeStamp) {
        TimeStamp = timeStamp;
    }

    public void setSpareKeys(String[] spareKeys) {
        this.spareKeys = spareKeys;
    }

    public void setAccess(accessGenerator access) {
        this.access = access;
    }

    public void setPrime(primaryOwner prime) {
        this.prime = prime;
    }

    public void setOwnerID(String ownerID) {
        OwnerID = ownerID;
    }

    public int getKeyID() {
        return keyID;
    }

    public String getKeyName() {
        return keyName;
    }

    public String getPasswordKey() {
        return PasswordKey;
    }

    public Date getTimeStamp() {
        return TimeStamp;
    }

    public String[] getSpareKeys() {
        return spareKeys;
    }

    public accessGenerator getAccess() {
        return access;
    }

    public String getOwnerID() {
        return OwnerID;
    }




}
