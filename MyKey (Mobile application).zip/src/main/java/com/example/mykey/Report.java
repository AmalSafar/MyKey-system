package com.example.mykey;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import Controller.DatabaseHandler;
import Model.Owner;
import Model.User;
import Model.Users;
import Model.temproaryUser;

import java.sql.Date;
import java.util.ArrayList;

public class Report extends AppCompatActivity {
    /**
     * Default constructor
     */

    DatabaseHandler DB = new DatabaseHandler(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.report_page);
        getSupportActionBar().setTitle("Lock's report");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        displayTempUsers();
        //generate PDF that contain the report
    }

    public Report() {
    }

    public Report(int contentLayoutId) {

        super(contentLayoutId);
    }


    private int enteranceTime;
    private Date date;
    private temproaryUser enteredUser;
    private ArrayList<temproaryUser>tempUsers = new ArrayList<temproaryUser>();
    private String statusQR;
    private int exitTime;
    private Users users;


    public void displayTempUsers() {

        this.tempUsers = DB.getProvideAccess();
        if (tempUsers.size() != 0) {
            String[] usersName = new String[tempUsers.size()];
            for (int i = 0; i < this.tempUsers.size(); i++) {
                usersName[i] = this.tempUsers.get(i).getUserName();
            }

            //
            ListView listView = (ListView) findViewById(R.id.temp_users_list);
            ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, usersName);
            listView.setAdapter(arrayAdapter);
            //select the required key from key cahin
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                    for (int j = 0; j < tempUsers.size(); j++) {
                        if (i == j) {
                            setContentView(R.layout.temporary_access_details);
                            TextView userName = (TextView)findViewById(R.id.userName_text);
                            TextView keyName = (TextView)findViewById(R.id.Key_name_text);
                            TextView DateFrom = (TextView)findViewById(R.id.date_from_text);
                            TextView DateTo = (TextView)findViewById(R.id.date_to_text);
                            TextView TimeFrom = (TextView)findViewById(R.id.time_from_text);
                            TextView TimeTo = (TextView)findViewById(R.id.time_to_text);
                            TextView access_type = (TextView)findViewById(R.id.access_type_text);
                            TextView access_status = (TextView)findViewById(R.id.access_status_text);

                            userName.setText(tempUsers.get(j).getUserName());
                            keyName.setText(tempUsers.get(j).getKeyName());
                            DateFrom.setText(tempUsers.get(j).getDateFrom());
                            DateTo.setText(tempUsers.get(j).getDateTo());
                            TimeFrom.setText(tempUsers.get(j).getEnteranceTime());
                            TimeTo.setText(tempUsers.get(j).getExitTime());
                            access_type.setText(tempUsers.get(j).getAccessType());
                            access_status.setText(tempUsers.get(j).getAccessStatus());


                        }
                    }

                }
            });
        }

    }
    public void getLogs(){

        DB.displayReport((User) users);

    }

    public Report generateReport(){
        // TODO implement here
        return null;
    }
}
